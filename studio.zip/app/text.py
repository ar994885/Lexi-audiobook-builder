"""Text helpers: TTS sanitising, filenames, sentence splitting.

The sentence splitter mirrors what the LexiVoice Android app does with
``java.text.BreakIterator.getSentenceInstance()`` closely enough that sentence
indices in the generated ``sync_map.json`` line up with the indices the app
computes for the same EPUB chapter. Where the two disagree, the app still
finds the sentence by text, so a near-miss degrades to a small jump rather
than a broken read-along.
"""
from __future__ import annotations

import re
import unicodedata

_WS = re.compile(r"\s+")

# Terminators that end a sentence, optionally followed by closing quotes or
# brackets:  .  !  ?  …  ”  ’  )  ]
_TERMINATOR = re.compile(r"[.!?…]+[\"'”’»)\]]*(?=\s|$)")

# Abbreviations whose trailing period does not end a sentence.
_ABBREVIATIONS = {
    "mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "vs", "etc", "eg",
    "ie", "no", "vol", "vols", "pp", "p", "ch", "fig", "figs", "cf", "al",
    "inc", "ltd", "co", "dept", "univ", "approx", "est", "ca", "jan", "feb",
    "mar", "apr", "jun", "jul", "aug", "sep", "sept", "oct", "nov", "dec",
    "gen", "col", "capt", "lt", "sgt", "rev", "hon", "gov", "sen", "rep",
}

# A fragment made only of these is the tail of the previous sentence.
ORPHAN_CLOSERS = set("]]］】》〉」』）)｝}〕〗〙〛”’")


def collapse_ws(text: str) -> str:
    return _WS.sub(" ", text).strip()


def sanitize_for_tts(text: str) -> str:
    """Strip characters that make the speech service stumble, keep punctuation."""
    text = text.replace("\u00ad", "")
    text = re.sub(r"[\u2014\u2013]", ", ", text)
    text = re.sub(r"[.…]{2,}", ".", text)
    text = re.sub(r"([.!?]){2,}", r"\1", text)
    text = "".join(
        ch for ch in text
        if ch.isalnum() or ch in " \t\n.,!?;:'\"“”‘’()[]-&%$" or unicodedata.category(ch).startswith("M")
    )
    return collapse_ws(text)


def is_orphan_closer(text: str) -> bool:
    trimmed = text.strip()
    return bool(trimmed) and all(ch in ORPHAN_CLOSERS for ch in trimmed)


def split_sentences(text: str) -> list[str]:
    """Split one paragraph into sentences, keeping the paragraph's own words."""
    text = text.strip()
    if not text:
        return []

    sentences: list[str] = []
    start = 0
    for match in _TERMINATOR.finditer(text):
        end = match.end()
        # A following word in lower case usually means an abbreviation or a
        # decimal, not a new sentence ("Mr. smith", "3.5 miles").
        rest = text[end:].lstrip()
        if not rest:
            continue
        head = re.split(r"\s", text[start:match.start()].strip())[-1] if text[start:match.start()].strip() else ""
        word = head.strip("(\"'“‘").lower()
        if word in _ABBREVIATIONS:
            continue
        if rest[0].islower() and word not in {"", "you"}:
            # ICU does not break before lower case either.
            continue
        sentence = text[start:end].strip()
        if sentence:
            sentences.append(sentence)
        start = end

    tail = text[start:].strip()
    if tail:
        sentences.append(tail)

    if not sentences:
        return [text]

    # Fold fragments that are only closing brackets into the previous sentence,
    # exactly like the app does, so the sentence count matches.
    merged: list[str] = []
    for sentence in sentences:
        if merged and is_orphan_closer(sentence):
            merged[-1] = collapse_ws(merged[-1] + " " + sentence)
        else:
            merged.append(sentence)
    return merged


def slugify(value: str, max_len: int = 80) -> str:
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[^\w\s.-]", "", value).strip()
    value = re.sub(r"\s+", " ", value)
    value = value.replace("/", "-").strip(" .")
    if len(value) > max_len:
        value = value[:max_len].rstrip(" .-")
    return value or "audiobook"


def human_duration(ms: float) -> str:
    total = int(ms // 1000)
    hours, rem = divmod(total, 3600)
    minutes, seconds = divmod(rem, 60)
    if hours:
        return f"{hours}h {minutes:02d}m"
    if minutes:
        return f"{minutes}m {seconds:02d}s"
    return f"{seconds}s"
