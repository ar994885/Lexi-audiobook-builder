"""FastAPI server for LexiVoice Studio."""
from __future__ import annotations

import asyncio
import shutil
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import config, engines, epubbook
from .jobs import manager

MIME = {
    ".m4b": "audio/mp4",
    ".mp3": "audio/mpeg",
    ".zip": "application/zip",
    ".json": "application/json",
    ".epub": "application/epub+zip",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".txt": "text/plain; charset=utf-8",
}


@asynccontextmanager
async def lifespan(app: FastAPI):
    manager.start()
    yield
    await manager.stop()


app = FastAPI(title="LexiVoice Studio", version=config.VERSION, lifespan=lifespan)


# --------------------------------------------------------------------------
# pages
# --------------------------------------------------------------------------

@app.get("/")
async def index():
    return FileResponse(config.WEB_DIR / "index.html")


app.mount("/static", StaticFiles(directory=config.WEB_DIR), name="static")


@app.get("/api/health")
async def health():
    return {
        "version": config.VERSION,
        "build": config.BUILD_STAMP,
        "ttsProxy": bool(config.TTS_PROXY),
        "maxJobs": config.MAX_JOBS_IN_FLIGHT,
    }


# --------------------------------------------------------------------------
# books
# --------------------------------------------------------------------------

@app.post("/api/books")
async def upload_book(file: UploadFile = File(...)):
    if not file.filename or not file.filename.lower().endswith(".epub"):
        raise HTTPException(400, "Please choose an .epub file")

    book_id = uuid.uuid4().hex[:10]
    book_dir = config.BOOKS_DIR / book_id
    book_dir.mkdir(parents=True, exist_ok=True)
    # Keep the book's own file name: LexiVoice links an audiobook to its EPUB by
    # name, so `sourceEpubKey` must be the name the user's copy actually has.
    epub_path = book_dir / _epub_name(file.filename)

    size = 0
    try:
        with open(epub_path, "wb") as out:
            while chunk := await file.read(1 << 20):
                size += len(chunk)
                if size > config.MAX_UPLOAD_BYTES:
                    raise HTTPException(413, "That EPUB is larger than the configured limit")
                out.write(chunk)
    except HTTPException:
        shutil.rmtree(book_dir, ignore_errors=True)
        raise
    finally:
        await file.close()

    try:
        parsed = await asyncio.to_thread(epubbook.parse_epub, epub_path)
    except Exception as exc:  # noqa: BLE001 - user-facing
        shutil.rmtree(book_dir, ignore_errors=True)
        raise HTTPException(400, f"Could not read that EPUB: {exc}") from exc

    cover, cover_ext = await asyncio.to_thread(_cover_for, epub_path)
    parsed["coverExt"] = cover_ext
    parsed["originalName"] = file.filename
    await asyncio.to_thread(epubbook.save_book, book_dir, parsed, cover)

    summary = epubbook.summarize(parsed)
    summary["bookId"] = book_id
    summary["originalName"] = file.filename
    summary["sizeBytes"] = size
    summary["hasCover"] = cover is not None
    return summary


def _epub_name(filename: str) -> str:
    name = Path(filename).name.replace("\\", "/").split("/")[-1]
    name = "".join(ch for ch in name if ch.isalnum() or ch in " ._-()[]&,'")
    name = name.strip(" .") or "book"
    if not name.lower().endswith(".epub"):
        name += ".epub"
    return name[:120]


def _cover_for(epub_path: Path):
    from ebooklib import epub as _epub

    book = _epub.read_epub(str(epub_path), options={"ignore_ncx": False})
    return epubbook._cover_bytes(book)  # noqa: SLF001 - same module family


@app.get("/api/books/{book_id}")
async def get_book(book_id: str):
    book_dir = _safe_dir(config.BOOKS_DIR, book_id)
    if not (book_dir / "book.json").exists():
        raise HTTPException(404, "Book not found")
    parsed = await asyncio.to_thread(epubbook.load_book, book_dir)
    summary = epubbook.summarize(parsed)
    summary["bookId"] = book_id
    summary["originalName"] = parsed.get("originalName", "")
    summary["hasCover"] = any(book_dir.glob("cover.*"))
    return summary


@app.get("/api/books/{book_id}/cover")
async def get_cover(book_id: str):
    book_dir = _safe_dir(config.BOOKS_DIR, book_id)
    covers = sorted(book_dir.glob("cover.*"))
    if not covers:
        raise HTTPException(404, "No cover")
    return FileResponse(covers[0])


@app.delete("/api/books/{book_id}")
async def delete_book(book_id: str):
    book_dir = _safe_dir(config.BOOKS_DIR, book_id)
    shutil.rmtree(book_dir, ignore_errors=True)
    return {"ok": True}


# --------------------------------------------------------------------------
# voices
# --------------------------------------------------------------------------

@app.get("/api/engines")
async def get_engines():
    return {
        "engines": await asyncio.to_thread(engines.list_engines),
        "default": {"engine": "edge", "voice": engines.DEFAULT_VOICE},
    }


@app.get("/api/engines/{engine_id}/voices")
async def engine_voices(engine_id: str):
    try:
        engine = engines.get_engine(engine_id)
    except engines.EngineError as exc:
        raise HTTPException(404, str(exc)) from exc
    listing = await engine.voices()
    ok, detail = engine.available()
    return {
        "engine": engine.id,
        "available": ok,
        "detail": detail,
        "granularity": engine.granularity,
        "presets": engine.presets(),
        "voices": listing,
    }


@app.post("/api/engines/{engine_id}/models")
async def upload_model(
    engine_id: str,
    model: UploadFile = File(...),
    modelConfig: UploadFile | None = File(None),
):
    """Add a voice model.

    * `local` (Piper): the `.onnx` **and** its `.onnx.json`.
    * `pocket` (Pocket TTS): a single self-contained `.onnx`; the voices travel
      inside the file, so there is no config to upload.
    """
    if engine_id not in ("local", "pocket"):
        raise HTTPException(400, "that engine does not take models")
    if not model.filename or not model.filename.lower().endswith(".onnx"):
        raise HTTPException(400, "Choose the model's .onnx file")

    onnx_bytes = await model.read()
    config_bytes = await modelConfig.read() if modelConfig else None
    stem = Path(model.filename).name[:-5]

    # A Pocket TTS file is self-contained, so a missing .onnx.json means the
    # user picked the wrong engine, not that the upload is broken.
    if engine_id == "local" and config_bytes is None:
        try:
            added = await asyncio.to_thread(engines.pocket.register_model, onnx_bytes, stem)
            return {"ok": True, "engine": "pocket", "model": added["model"],
                    "voices": engines.discover_pocket_voices()}
        except engines.EngineError as exc:
            raise HTTPException(400, "A Piper voice needs its .onnx.json next to the .onnx. "
                                     f"(And this file is not a Pocket TTS model either: {exc})") from exc

    try:
        if engine_id == "pocket":
            added = await asyncio.to_thread(engines.pocket.register_model, onnx_bytes, stem)
            return {"ok": True, "engine": "pocket", "model": added["model"],
                    "voices": engines.discover_pocket_voices()}
        voice = await asyncio.to_thread(engines.register_model, stem, onnx_bytes, config_bytes,
                                        modelConfig.filename if modelConfig else None)
        return {"ok": True, "engine": "local", "voice": voice,
                "voices": engines.discover_local_voices()}
    except engines.EngineError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post("/api/engines/pocket/clones")
async def clone_voice(
    model: str = Form(...),
    name: str = Form(...),
    sample: UploadFile = File(...),
):
    """Clone a voice from a short recording and keep it as a prompt."""
    if not sample.filename or not sample.filename.lower().endswith((".wav", ".flac", ".mp3", ".m4a")):
        raise HTTPException(400, "Choose a short .wav recording")
    engine = engines.get_engine("pocket")
    target = config.DATA_DIR / "uploads" / f"{uuid.uuid4().hex[:8]}-{Path(sample.filename).name}"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(await sample.read())
    try:
        voice = await asyncio.to_thread(engine.clone_from_wav, model, name, target)
    except engines.EngineError as exc:
        raise HTTPException(400, str(exc)) from exc
    finally:
        target.unlink(missing_ok=True)
    return {"ok": True, "voice": voice, "voices": engines.discover_pocket_voices()}


# --------------------------------------------------------------------------
# jobs
# --------------------------------------------------------------------------

class JobRequest(BaseModel):
    bookId: str
    chapters: list[int] = Field(default_factory=list)
    voice: str = engines.DEFAULT_VOICE
    engine: str = "edge"
    rate: float = 0.0
    pitch: float = 0.0
    mode: str = "m4b"
    bitrate: int = 64000
    concurrency: int = 3
    chapterGapMs: int = 900
    chunkGapMs: int = 120
    chunkChars: int = 900
    narratorLabel: str = "LexiVoice Studio"
    year: str = "2026"
    genre: str = "Audiobook"


@app.post("/api/jobs")
async def create_job(request: JobRequest):
    book_dir = _safe_dir(config.BOOKS_DIR, request.bookId)
    if not (book_dir / "book.json").exists():
        raise HTTPException(404, "Book not found")
    parsed = await asyncio.to_thread(epubbook.load_book, book_dir)
    known = {c["index"] for c in parsed["chapters"]}
    chapters = [c for c in request.chapters if c in known]
    if not chapters:
        raise HTTPException(400, "Select at least one chapter")
    if request.mode not in ("m4b", "mp3"):
        raise HTTPException(400, "mode must be 'm4b' or 'mp3'")

    options = request.model_dump()
    options["chapters"] = sorted(chapters)
    options["concurrency"] = max(1, min(6, int(request.concurrency)))
    options["bitrate"] = max(32000, min(192000, int(request.bitrate)))

    job = manager.create(request.bookId, parsed["title"], options)
    return _job_view(job)


@app.get("/api/jobs")
async def list_jobs():
    return {"jobs": [_job_view(job) for job in manager.list()[:40]]}


@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    job = manager.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return _job_view(job)


@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str):
    if not manager.cancel(job_id):
        raise HTTPException(409, "That job already finished")
    return _job_view(manager.get(job_id))


@app.delete("/api/jobs/{job_id}")
async def delete_job(job_id: str):
    job = manager.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    if job["status"] == "running":
        raise HTTPException(409, "Stop the conversion first")
    shutil.rmtree(manager.job_dir(job_id), ignore_errors=True)
    manager.jobs.pop(job_id, None)
    return {"ok": True}


@app.get("/api/jobs/{job_id}/files/{name}")
async def download(job_id: str, name: str):
    job = manager.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    if "/" in name or "\\" in name or name.startswith("."):
        raise HTTPException(400, "Bad file name")

    job_dir = manager.job_dir(job_id)
    candidates = [job_dir / name]
    if job.get("result"):
        candidates.append(job_dir / "out" / job["result"]["folder"] / name)
    for path in candidates:
        if path.is_file():
            return FileResponse(
                path,
                media_type=MIME.get(path.suffix.lower(), "application/octet-stream"),
                filename=name,
                headers={"Cache-Control": "no-store"},
            )
    raise HTTPException(404, "File not found")


@app.get("/api/jobs/{job_id}/bundle")
async def download_bundle(job_id: str):
    job = manager.get(job_id)
    if not job or not job.get("result"):
        raise HTTPException(404, "Nothing to download yet")
    name = next((o["name"] for o in job["result"]["outputs"] if o["kind"] == "zip"), None)
    if not name:
        raise HTTPException(404, "Bundle missing")
    return await download(job_id, name)


def _job_view(job: dict) -> dict:
    view = {
        key: job.get(key)
        for key in (
            "id", "bookId", "bookTitle", "status", "stage", "fraction", "message",
            "chapter", "chapterPosition", "chapterCount", "result", "error", "options",
        )
    }
    view["createdAt"] = job.get("createdAt")
    view["updatedAt"] = job.get("updatedAt")
    view["log"] = [entry["message"] for entry in job.get("log", [])][-12:]
    view["files"] = []
    if job.get("result"):
        for output in job["result"]["outputs"]:
            view["files"].append({
                "name": output["name"],
                "kind": output["kind"],
                "bytes": output["bytes"],
                "url": f"/api/jobs/{job['id']}/files/{output['name']}",
            })
    return view


def _safe_dir(root: Path, name: str) -> Path:
    if "/" in name or "\\" in name or name in (".", "..") or not name:
        raise HTTPException(400, "Bad id")
    path = (root / name).resolve()
    if root.resolve() not in path.parents and path != root.resolve():
        raise HTTPException(400, "Bad id")
    return path


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": f"{type(exc).__name__}: {exc}"})


def main() -> None:
    import uvicorn

    print(f"LexiVoice Studio {config.VERSION} ({config.BUILD_STAMP})")
    print(f"  listening on http://{config.HOST}:{config.PORT}")
    print(f"  data in {config.DATA_DIR}")
    uvicorn.run("app.main:app", host=config.HOST, port=config.PORT, reload=False)


if __name__ == "__main__":
    main()
