"""Audio: decode the speech MP3, glue chapters into WAV, encode M4B / MP3.

PyAV ships its own FFmpeg libraries, so there is no system ffmpeg to install:
`pip install av` is enough on Windows, macOS and Linux.
"""
from __future__ import annotations

import io
import wave
from pathlib import Path

import av
import numpy as np

SAMPLE_RATE = 24000
CHANNELS = 1
SAMPLE_WIDTH = 2  # int16


def decode_mp3(data: bytes, rate: int = SAMPLE_RATE) -> np.ndarray:
    """Decode MP3 bytes to mono int16 PCM at ``rate``."""
    with av.open(io.BytesIO(data), mode="r") as container:
        if not container.streams.audio:
            return np.zeros(0, dtype=np.int16)
        resampler = av.AudioResampler(format="s16", layout="mono", rate=rate)
        chunks: list[np.ndarray] = []
        for frame in container.decode(audio=0):
            for resampled in resampler.resample(frame):
                chunks.append(resampled.to_ndarray().reshape(-1))
        for resampled in resampler.resample(None):
            chunks.append(resampled.to_ndarray().reshape(-1))
    if not chunks:
        return np.zeros(0, dtype=np.int16)
    return np.concatenate(chunks).astype(np.int16, copy=False)


def resample(pcm: np.ndarray, src_rate: int, dst_rate: int = SAMPLE_RATE) -> np.ndarray:
    """Resample mono int16 PCM (local voices run at 16/22.05 kHz)."""
    if src_rate == dst_rate or pcm.size == 0:
        return pcm.astype(np.int16, copy=False)
    frame = av.AudioFrame.from_ndarray(pcm.reshape(1, -1).astype(np.int16), format="s16", layout="mono")
    frame.sample_rate = src_rate
    resampler = av.AudioResampler(format="s16", layout="mono", rate=dst_rate)
    parts = [f.to_ndarray().reshape(-1) for f in resampler.resample(frame)]
    parts += [f.to_ndarray().reshape(-1) for f in resampler.resample(None)]
    if not parts:
        return np.zeros(0, dtype=np.int16)
    return np.concatenate(parts).astype(np.int16, copy=False)


def silence(ms: float, rate: int = SAMPLE_RATE) -> np.ndarray:
    return np.zeros(int(rate * ms / 1000.0), dtype=np.int16)


class WavWriter:
    """Streams PCM to a WAV file so long chapters never sit in memory."""

    def __init__(self, path: Path, rate: int = SAMPLE_RATE):
        self.path = path
        self.rate = rate
        self.samples = 0
        path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = wave.open(str(path), "wb")
        self._fh.setnchannels(CHANNELS)
        self._fh.setsampwidth(SAMPLE_WIDTH)
        self._fh.setframerate(rate)

    def write(self, pcm: np.ndarray) -> None:
        if pcm.size == 0:
            return
        self._fh.writeframes(pcm.astype(np.int16, copy=False).tobytes())
        self.samples += int(pcm.size)

    def write_silence(self, ms: float) -> None:
        self.write(silence(ms, self.rate))

    @property
    def duration_ms(self) -> float:
        return self.samples * 1000.0 / self.rate

    def close(self) -> None:
        self._fh.close()


def read_wav(path: Path, block: int = 24000):
    """Yield int16 mono blocks from a WAV file."""
    with wave.open(str(path), "rb") as fh:
        while True:
            raw = fh.readframes(block)
            if not raw:
                break
            yield np.frombuffer(raw, dtype=np.int16)


def encode_m4b(
    chapter_wavs: list[tuple[Path, str]],
    out_path: Path,
    bitrate: int = 64000,
    gap_ms: float = 0.0,
    rate: int = SAMPLE_RATE,
) -> dict:
    """Encode chapter WAVs into one AAC .mp4 and return chapter timings.

    ``gap_ms`` of silence is written after each chapter except the last; the
    reported chapter duration includes that gap so the app's cumulative
    timeline (which just adds durations) lands on the real chapter start.
    """
    out_path.parent.mkdir(parents=True, exist_ok=True)
    container = av.open(str(out_path), mode="w", format="mp4")
    stream = container.add_stream("aac", rate=rate, layout="mono")
    stream.codec_context.bit_rate = bitrate

    chapters = []
    total_samples = 0
    gap_samples = int(rate * gap_ms / 1000.0)

    for position, (wav_path, title) in enumerate(chapter_wavs):
        start_ms = total_samples * 1000.0 / rate
        chapter_samples = 0
        for pcm in read_wav(wav_path):
            frame = av.AudioFrame.from_ndarray(pcm.reshape(1, -1), format="s16", layout="mono")
            frame.sample_rate = rate
            for packet in stream.encode(frame):
                container.mux(packet)
            chapter_samples += int(pcm.size)

        is_last = position == len(chapter_wavs) - 1
        trailing = 0 if is_last else gap_samples
        if trailing:
            zeros = np.zeros(trailing, dtype=np.int16)
            frame = av.AudioFrame.from_ndarray(zeros.reshape(1, -1), format="s16", layout="mono")
            frame.sample_rate = rate
            for packet in stream.encode(frame):
                container.mux(packet)

        total_samples += chapter_samples + trailing
        chapters.append({
            "title": title,
            "startMs": int(round(start_ms)),
            "durationMs": int(round((chapter_samples + trailing) * 1000.0 / rate)),
            "audioMs": int(round(chapter_samples * 1000.0 / rate)),
        })

    for packet in stream.encode(None):
        container.mux(packet)
    container.close()

    return {"chapters": chapters, "totalMs": int(round(total_samples * 1000.0 / rate))}


def encode_mp3(wav_path: Path, out_path: Path, bitrate: int = 64000, rate: int = SAMPLE_RATE) -> int:
    """Encode one chapter WAV to MP3. Returns the duration in milliseconds."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    container = av.open(str(out_path), mode="w", format="mp3")
    stream = container.add_stream("libmp3lame", rate=rate, layout="mono")
    stream.codec_context.bit_rate = bitrate
    samples = 0
    for pcm in read_wav(wav_path):
        frame = av.AudioFrame.from_ndarray(pcm.reshape(1, -1), format="s16", layout="mono")
        frame.sample_rate = rate
        for packet in stream.encode(frame):
            container.mux(packet)
        samples += int(pcm.size)
    for packet in stream.encode(None):
        container.mux(packet)
    container.close()
    return int(round(samples * 1000.0 / rate))
