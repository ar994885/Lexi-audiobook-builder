"""Local engine: any Piper-format ONNX voice on disk.

A "voice" is a pair of files:

    models/<name>/<name>.onnx
    models/<name>/<name>.onnx.json     <- sample rate, phoneme map, speakers

That is the layout the Piper project and Hugging Face
(``rhasspy/piper-voices``) ship, and the layout the uploader in this app writes.
Because the model runs on your own CPU, it needs no network and costs nothing —
and synthesising one sentence at a time gives the read-along exact timings.

Speed is applied with Piper's ``length_scale`` (higher = slower). Pitch is not
part of the model, so it is ignored here rather than faked.
"""
from __future__ import annotations

import asyncio
import json
import threading
from pathlib import Path

import numpy as np

from .. import config
from .base import Engine, EngineError, SynthResult


def _model_dirs() -> list[Path]:
    if not config.MODELS_DIR.exists():
        return []
    return sorted(p for p in config.MODELS_DIR.iterdir() if p.is_dir() and not p.name.startswith("."))


def _pair_for(folder: Path) -> tuple[Path, Path] | None:
    onnx_files = sorted(folder.glob("*.onnx"))
    for onnx in onnx_files:
        for candidate in (onnx.with_suffix(".onnx.json"), folder / "config.json",
                          folder / f"{onnx.stem}.json"):
            if candidate.exists():
                return onnx, candidate
    return None


def _pretty_label(name: str) -> str:
    """`en_US-amy-low` -> `Amy — en-US (low)`."""
    parts = name.split("-")
    if len(parts) >= 2 and "_" in parts[0]:
        locale, speaker = parts[0], parts[1]
        quality = "-".join(parts[2:]) if len(parts) > 2 else ""
        label = f"{speaker.replace('_', ' ').title()} — {locale.replace('_', '-')}"
        if quality:
            label += f" ({quality})"
        return label
    return name.replace("_", " ")


def discover() -> list[dict]:
    """Every usable local voice, with the metadata the picker shows."""
    found = []
    for folder in _model_dirs():
        pair = _pair_for(folder)
        if not pair:
            found.append({
                "id": folder.name,
                "label": folder.name,
                "broken": True,
                "reason": "missing the .onnx.json config next to the model",
            })
            continue
        onnx_path, config_path = pair
        try:
            with open(config_path, "r", encoding="utf-8") as fh:
                meta = json.load(fh)
            sample_rate = int(meta.get("audio", {}).get("sample_rate", 22050))
            speakers = meta.get("num_speakers", 1) or 1
            speaker_map = meta.get("speaker_id_map", {}) or {}
        except Exception as exc:  # noqa: BLE001
            found.append({"id": folder.name, "label": folder.name, "broken": True,
                          "reason": f"unreadable config: {exc}"})
            continue

        base = {
            "id": folder.name,
            "label": _pretty_label(folder.name),
            "locale": folder.name.split("_")[0] if "_" in folder.name else "",
            "sampleRate": sample_rate,
            "engine": "local",
            "sizeBytes": onnx_path.stat().st_size,
            "speakers": speakers,
        }
        if speakers > 1 and speaker_map:
            for speaker_name, speaker_id in sorted(speaker_map.items(), key=lambda kv: kv[1]):
                found.append({**base,
                              "id": f"{folder.name}#{speaker_id}",
                              "label": f"{base['label']} — {speaker_name}",
                              "gender": ""})
        else:
            found.append(base)
    return found


class LocalOnnxEngine(Engine):
    id = "local"
    label = "Local — ONNX voice on this machine"
    description = "Piper-format .onnx voices. No network, no quota; speed depends on your CPU."
    granularity = "sentence"

    def __init__(self) -> None:
        self._voices: dict[str, object] = {}
        self._lock = threading.Lock()

    def available(self) -> tuple[bool, str]:
        try:
            import piper  # noqa: F401
        except Exception:
            return False, "piper-tts is not installed (pip install piper-tts)"
        if not discover():
            return False, "No ONNX voice in the models folder yet"
        return True, ""

    async def voices(self) -> list[dict]:
        return [v for v in discover() if not v.get("broken")]

    def presets(self) -> list[dict]:
        # Every local voice is already listed, so there is nothing to pin on top.
        return []

    # ------------------------------------------------------------------ model
    def _load(self, voice_id: str):
        with self._lock:
            cached = self._voices.get(voice_id)
            if cached is not None:
                return cached
            name, _, speaker = voice_id.partition("#")
            folder = config.MODELS_DIR / name
            pair = _pair_for(folder)
            if not pair:
                raise EngineError(f"voice '{name}' is missing its .onnx.json config")
            try:
                from piper import PiperVoice
            except Exception as exc:  # noqa: BLE001
                raise EngineError(f"piper-tts is not installed: {exc}") from exc
            try:
                loaded = PiperVoice.load(str(pair[0]), str(pair[1]))
            except Exception as exc:  # noqa: BLE001
                raise EngineError(f"could not load '{name}': {exc}") from exc
            self._voices[voice_id] = (loaded, speaker)
            return loaded, speaker

    def _synthesize_sync(self, text: str, voice_id: str, rate: float) -> SynthResult:
        voice, speaker = self._load(voice_id)
        from piper.config import SynthesisConfig

        length_scale = 1.0 / max(0.3, 1.0 + rate / 100.0)
        speaker_id = int(speaker) if speaker.isdigit() else None
        config = SynthesisConfig(length_scale=length_scale, speaker_id=speaker_id)

        pcm_parts: list[np.ndarray] = []
        sample_rate = 22050
        for chunk in voice.synthesize(text, syn_config=config):
            sample_rate = chunk.sample_rate
            pcm_parts.append(np.frombuffer(chunk.audio_int16_bytes, dtype=np.int16))
        if not pcm_parts:
            raise EngineError("the voice produced no audio")
        return SynthResult(pcm=np.concatenate(pcm_parts), sample_rate=sample_rate, boundaries=[])

    async def synthesize(self, text: str, voice: str, rate: float = 0.0, pitch: float = 0.0) -> SynthResult:
        if not voice:
            voices = await self.voices()
            if not voices:
                raise EngineError("no local voice is installed")
            voice = voices[0]["id"]
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._synthesize_sync, text, voice, rate)


def register_model(folder_name: str, onnx_bytes: bytes, config_bytes: bytes | None,
                   config_name: str | None = None) -> dict:
    """Store an uploaded .onnx (+ .onnx.json) as a usable voice."""
    name = "".join(ch for ch in folder_name if ch.isalnum() or ch in "-_.") or "voice"
    folder = config.MODELS_DIR / name
    folder.mkdir(parents=True, exist_ok=True)
    onnx_path = folder / f"{name}.onnx"
    onnx_path.write_bytes(onnx_bytes)

    if config_bytes is None:
        raise EngineError("the .onnx.json config is required — Piper voices cannot phonemise without it")
    try:
        meta = json.loads(config_bytes.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise EngineError(f"the config is not valid JSON: {exc}") from exc
    if "audio" not in meta:
        raise EngineError("the config has no 'audio' section — is this a Piper voice?")

    config_path = folder / (config_name or f"{name}.onnx.json")
    config_path.write_bytes(config_bytes)

    for voice in discover():
        if voice["id"].startswith(name):
            return voice
    raise EngineError("the model was saved but could not be opened")
