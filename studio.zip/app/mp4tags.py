"""MP4 box editing: Nero `chpl` chapters, iTunes tags and cover art.

This is a Python port of ``Mp4ChapterAndMetadataWriter`` from the LexiVoice
Android app, so the files it writes are read back by the app's own
``findBox`` / ``readChplChapters`` code path without special cases.

Two things matter for the app:

* ``moov/udta/chpl`` (or ``moov/chpl``) holds the chapter list. Each entry is a
  100-nanosecond start time plus a length-prefixed UTF-8 title.
* ``moov/udta/meta/ilst`` holds the tags the app shows in its library, with
  ``covr`` for the cover art.

The rewrite is streaming: only ``moov`` is held in memory, so a 600 MB
audiobook does not need 600 MB of RAM.
"""
from __future__ import annotations

import shutil
import struct
from pathlib import Path

TEXT_TAGS = {
    "title": b"\xa9nam",
    "author": b"\xa9ART",
    "album": b"\xa9alb",
    "narrator": b"\xa9wrt",
    "year": b"\xa9day",
    "genre": b"\xa9gen",
    "album_artist": b"aART",
}


def _box(box_type: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", 8 + len(payload)) + box_type + payload


def _iter_boxes(fh, end: int):
    """Yield (type, offset, size) for the boxes between the current position and `end`."""
    pos = fh.tell()
    while pos + 8 <= end:
        fh.seek(pos)
        header = fh.read(8)
        if len(header) < 8:
            break
        size, box_type = struct.unpack(">I4s", header)
        header_size = 8
        if size == 1:
            large = fh.read(8)
            if len(large) < 8:
                break
            size = struct.unpack(">Q", large)[0]
            header_size = 16
        elif size == 0:
            size = end - pos
        if size < header_size or pos + size > end:
            break
        yield box_type, pos, size
        pos += size


def _split_children(payload: bytes):
    """Yield (type, raw box bytes) for a container payload."""
    pos = 0
    total = len(payload)
    while pos + 8 <= total:
        size = struct.unpack(">I", payload[pos:pos + 4])[0]
        header = 8
        if size == 1:
            if pos + 16 > total:
                break
            size = struct.unpack(">Q", payload[pos + 8:pos + 16])[0]
            header = 16
        elif size == 0:
            size = total - pos
        if size < header or pos + size > total:
            break
        yield payload[pos + 4:pos + 8], payload[pos:pos + size]
        pos += size


def build_chpl(chapters: list[dict]) -> bytes:
    """Nero chapter box, byte-for-byte compatible with the app's reader."""
    payload = bytearray()
    payload += struct.pack(">I", 0x01000000)  # version 1, flags 0
    payload += b"\x00"                        # reserved
    payload += struct.pack(">i", len(chapters))
    for chapter in chapters:
        start_100ns = int(chapter["startMs"]) * 10_000
        title = chapter["title"].encode("utf-8")[:255]
        payload += struct.pack(">Q", start_100ns)
        payload += struct.pack(">B", len(title))
        payload += title
    return _box(b"chpl", bytes(payload))


def _text_data_box(value: str) -> bytes:
    return _box(b"data", struct.pack(">II", 1, 0) + value.encode("utf-8"))


def build_ilst(tags: dict[str, str], cover: bytes | None, cover_is_png: bool = False) -> bytes:
    ilst = bytearray()
    for key, fourcc in TEXT_TAGS.items():
        value = (tags.get(key) or "").strip()
        if not value:
            continue
        ilst += _box(fourcc, _text_data_box(value))
    if cover:
        data_type = 14 if cover_is_png else 13  # 14 = PNG, 13 = JPEG
        ilst += _box(b"covr", _box(b"data", struct.pack(">II", data_type, 0) + cover))
    return _box(b"ilst", bytes(ilst))


def build_meta(tags: dict[str, str], cover: bytes | None, cover_is_png: bool = False) -> bytes:
    hdlr = _box(b"hdlr", struct.pack(">II", 0, 0) + b"mdir" + b"appl" + b"\x00" * 9)
    return _box(b"meta", b"\x00\x00\x00\x00" + hdlr + build_ilst(tags, cover, cover_is_png))


def _shift_chunk_offsets(buf: bytearray, start: int, end: int, delta: int) -> None:
    pos = start
    while pos + 8 <= end:
        size = struct.unpack(">I", buf[pos:pos + 4])[0]
        box_type = bytes(buf[pos + 4:pos + 8])
        if size < 8 or pos + size > end:
            return
        if box_type == b"stco" and pos + 16 <= end:
            count = struct.unpack(">I", buf[pos + 12:pos + 16])[0]
            for i in range(count):
                entry = pos + 16 + i * 4
                if entry + 4 > pos + size:
                    break
                old = struct.unpack(">I", buf[entry:entry + 4])[0]
                buf[entry:entry + 4] = struct.pack(">I", (old + delta) & 0xFFFFFFFF)
        elif box_type == b"co64" and pos + 16 <= end:
            count = struct.unpack(">I", buf[pos + 12:pos + 16])[0]
            for i in range(count):
                entry = pos + 16 + i * 8
                if entry + 8 > pos + size:
                    break
                old = struct.unpack(">Q", buf[entry:entry + 8])[0]
                buf[entry:entry + 8] = struct.pack(">Q", old + delta)
        elif box_type in (b"trak", b"mdia", b"minf", b"stbl"):
            _shift_chunk_offsets(buf, pos + 8, pos + size, delta)
        pos += size


def write_tags_and_chapters(
    path: Path,
    *,
    tags: dict[str, str],
    chapters: list[dict],
    cover: bytes | None = None,
    cover_is_png: bool = False,
    brand_m4b: bool = True,
) -> None:
    """Inject chapters and tags into an existing MP4/M4B file, in place."""
    path = Path(path)
    size = path.stat().st_size

    with open(path, "rb") as fh:
        boxes = list(_iter_boxes(fh, size))
        moov = next((b for b in boxes if b[0] == b"moov"), None)
        if moov is None:
            raise ValueError("no moov box: the encoder produced an unusable file")
        mdat = next((b for b in boxes if b[0] == b"mdat"), None)

        fh.seek(moov[1])
        old_moov = fh.read(moov[2])

    header_len = 8
    if struct.unpack(">I", old_moov[0:4])[0] == 1:
        header_len = 16
    moov_payload = old_moov[header_len:]

    udta_payload = bytearray()
    udta_payload += build_meta(tags, cover, cover_is_png)
    if chapters:
        udta_payload += build_chpl(chapters)
    new_udta = _box(b"udta", bytes(udta_payload))

    rebuilt = bytearray()
    replaced = False
    for box_type, raw in _split_children(moov_payload):
        if box_type == b"udta":
            rebuilt += new_udta
            replaced = True
        else:
            rebuilt += raw
    if not replaced:
        rebuilt += new_udta

    new_moov = struct.pack(">I", 8 + len(rebuilt)) + b"moov" + bytes(rebuilt)

    moov_before_mdat = mdat is not None and moov[1] < mdat[1]
    delta = len(new_moov) - moov[2]
    if moov_before_mdat and delta:
        patched = bytearray(new_moov)
        _shift_chunk_offsets(patched, 8, len(patched), delta)
        new_moov = bytes(patched)

    tmp_path = path.with_suffix(path.suffix + ".tmp")
    with open(path, "rb") as src, open(tmp_path, "wb") as dst:
        for box_type, offset, box_size in boxes:
            if box_type == b"moov":
                dst.write(new_moov)
            elif box_type == b"ftyp" and brand_m4b:
                src.seek(offset)
                data = bytearray(src.read(box_size))
                if len(data) >= 12:
                    data[8:12] = b"M4B "
                dst.write(data)
            else:
                src.seek(offset)
                remaining = box_size
                while remaining:
                    chunk = src.read(min(1 << 20, remaining))
                    if not chunk:
                        break
                    dst.write(chunk)
                    remaining -= len(chunk)
    shutil.move(str(tmp_path), str(path))


# --------------------------------------------------------------------------
# Readers — used to verify a build the same way the phone will read it.
# --------------------------------------------------------------------------

def _find_box(fh, start: int, end: int, path: list[bytes]):
    if not path:
        return None
    pos = start
    while pos + 8 <= end:
        fh.seek(pos)
        header = fh.read(8)
        if len(header) < 8:
            return None
        size = struct.unpack(">I", header[0:4])[0]
        box_type = header[4:8]
        header_size = 8
        if size == 1:
            large = fh.read(8)
            if len(large) < 8:
                return None
            size = struct.unpack(">Q", large)[0]
            header_size = 16
        elif size == 0:
            size = end - pos
        if size < header_size or pos + size > end:
            return None
        if box_type == path[0]:
            body_start = pos + header_size
            if len(path) == 1:
                return body_start, pos + size
            found = _find_box(fh, body_start, pos + size, path[1:])
            if found:
                return found
        pos += size
    return None


def read_chpl(path: Path) -> list[dict]:
    """Port of the app's `readChplChapters`."""
    path = Path(path)
    with open(path, "rb") as fh:
        total = path.stat().st_size
        found = (_find_box(fh, 0, total, [b"moov", b"udta", b"chpl"])
                 or _find_box(fh, 0, total, [b"moov", b"chpl"]))
        if not found:
            return []
        body_start, end = found
        fh.seek(body_start)
        payload = fh.read(end - body_start)

    if len(payload) < 9:
        return []
    _version_flags, _reserved, count = struct.unpack(">IBi", payload[0:9])
    count = max(0, min(count, 2000))
    pos = 9
    raw = []
    for _ in range(count):
        if pos + 9 > len(payload):
            break
        start_100ns = struct.unpack(">Q", payload[pos:pos + 8])[0]
        length = payload[pos + 8]
        pos += 9
        if pos + length > len(payload):
            break
        title = payload[pos:pos + length].decode("utf-8", "replace")
        pos += length
        raw.append((start_100ns / 10_000.0, title))

    chapters = []
    for i, (start_ms, title) in enumerate(raw):
        end_ms = raw[i + 1][0] if i + 1 < len(raw) else start_ms
        chapters.append({"index": i, "title": title, "startMs": int(start_ms), "endMs": int(end_ms)})
    return chapters


def read_ilst_tags(path: Path) -> dict:
    """Read back the tags and cover the app will show (via mutagen)."""
    from mutagen.mp4 import MP4

    audio = MP4(str(path))
    result = {}
    tags = audio.tags or {}
    for key, fourcc in TEXT_TAGS.items():
        # mutagen keys these atoms as str decoded from latin-1 (b"\xa9nam" -> "©nam").
        value = tags.get(fourcc.decode("latin-1"), [])
        result[key] = value[0] if value else ""
    covers = tags.get("covr", [])
    result["coverBytes"] = len(covers[0]) if covers else 0
    result["durationMs"] = int(round(audio.info.length * 1000)) if audio.info else 0
    return result
