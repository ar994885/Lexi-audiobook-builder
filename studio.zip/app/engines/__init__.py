"""Engine registry."""
from __future__ import annotations

from .base import Engine, EngineError, SynthResult
from .edge import DEFAULT_VOICE, PRESETS, EdgeEngine
from .piper import LocalOnnxEngine, discover as discover_local_voices, register_model
from .pocket import PocketEngine, discover as discover_pocket_voices

_ENGINES: dict[str, Engine] = {}


def get_engine(engine_id: str | None) -> Engine:
    key = engine_id or "edge"
    if key not in _ENGINES:
        if key == "edge":
            _ENGINES[key] = EdgeEngine()
        elif key == "local":
            _ENGINES[key] = LocalOnnxEngine()
        elif key == "pocket":
            _ENGINES[key] = PocketEngine()
        else:
            raise EngineError(f"unknown engine '{key}'")
    return _ENGINES[key]


def list_engines() -> list[dict]:
    out = []
    for engine_id in ("edge", "local", "pocket"):
        engine = get_engine(engine_id)
        ok, detail = engine.available()
        out.append({
            "id": engine.id,
            "label": engine.label,
            "description": engine.description,
            "granularity": engine.granularity,
            "available": ok,
            "detail": detail,
            "presets": engine.presets(),
        })
    return out


__all__ = [
    "Engine", "EngineError", "SynthResult", "get_engine", "list_engines",
    "DEFAULT_VOICE", "PRESETS", "discover_local_voices", "discover_pocket_voices",
    "register_model", "PocketEngine",
]
