/* LexiVoice Studio — front end. No framework, no CDN: it runs on a LAN too. */
const $ = (id) => document.getElementById(id);
const BUILD = "v1.2.3";

const state = {
  book: null,
  chapters: [],
  selected: new Set(),
  engine: "edge",
  voice: null,
  voices: [],
  engines: [],
  mode: "m4b",
  jobId: null,
  timer: null,
};

/* ------------------------------------------------------------------ utils */
async function api(path, options = {}) {
  const response = await fetch(path, options);
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { detail: text }; }
  if (!response.ok) throw new Error(data && data.detail ? data.detail : `HTTP ${response.status}`);
  return data;
}

function fmtBytes(bytes) {
  if (!bytes) return "";
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes, i = 0;
  while (value >= 1024 && i < units.length - 1) { value /= 1024; i += 1; }
  return `${value.toFixed(value < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}

function fmtDuration(ms) {
  const total = Math.round((ms || 0) / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h) return `${h}h ${String(m).padStart(2, "0")}m`;
  if (m) return `${m}m ${String(s).padStart(2, "0")}s`;
  return `${s}s`;
}

function show(step) {
  for (const id of ["stepUpload", "stepConfigure", "stepRunning", "stepDone"]) {
    $(id).hidden = id !== step;
  }
}

/* ------------------------------------------------------------------ health */
async function init() {
  $("buildStamp").textContent = BUILD;
  try {
    const health = await api("/api/health");
    $("healthPill").textContent = health.build ? `ready · ${health.build}` : "ready";
    $("healthPill").classList.add("ok");
    if (health.build) $("buildStamp").textContent = `${BUILD} · ${health.build}`;
  } catch {
    $("healthPill").textContent = "server offline";
  }

  const lan = location.host && !location.host.startsWith("localhost") && !location.host.startsWith("127.")
    ? `On your phone, open ${location.origin}`
    : "Tip: open this page from your phone with this computer's LAN address to download straight to the phone.";
  $("lanHint").textContent = lan;
  if (location.host && !location.host.startsWith("localhost")) {
    const link = $("phoneLink");
    link.href = location.origin;
    link.hidden = false;
  }

  wireUpload();
  wireConfigure();
  await loadEngines();
  await loadHistory();
}

/* ------------------------------------------------------------------ upload */
function wireUpload() {
  const zone = $("dropzone");
  const input = $("fileInput");

  zone.addEventListener("click", () => input.click());
  zone.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") { event.preventDefault(); input.click(); }
  });
  input.addEventListener("change", () => {
    if (input.files && input.files[0]) uploadBook(input.files[0]);
  });

  for (const type of ["dragenter", "dragover"]) {
    zone.addEventListener(type, (event) => { event.preventDefault(); zone.classList.add("drag"); });
  }
  for (const type of ["dragleave", "drop"]) {
    zone.addEventListener(type, (event) => { event.preventDefault(); zone.classList.remove("drag"); });
  }
  zone.addEventListener("drop", (event) => {
    const file = event.dataTransfer.files && event.dataTransfer.files[0];
    if (file) uploadBook(file);
  });
}

async function uploadBook(file) {
  const error = $("uploadError");
  error.hidden = true;
  if (!file.name.toLowerCase().endsWith(".epub")) {
    error.textContent = "That is not an .epub file.";
    error.hidden = false;
    return;
  }
  $("dropzone").querySelector("strong").textContent = `Reading ${file.name}…`;

  const form = new FormData();
  form.append("file", file);
  try {
    const book = await api("/api/books", { method: "POST", body: form });
    state.book = book;
    state.chapters = book.chapters;
    renderBook();
    show("stepConfigure");
  } catch (err) {
    error.textContent = err.message;
    error.hidden = false;
  } finally {
    $("dropzone").querySelector("strong").textContent = "Drop an EPUB here";
  }
}

/* --------------------------------------------------------------- configure */
function renderBook() {
  const book = state.book;
  $("bookTitle").textContent = book.title;
  $("bookAuthor").textContent = book.author || "Unknown author";
  $("statChapters").textContent = `${book.chapters.length} chapters`;
  $("statSentences").textContent = `${book.totalSentences.toLocaleString()} sentences`;
  $("statLength").textContent = `~${book.estimateLabel} of audio`;
  $("statLength").title = "Estimated from character count; real length depends on the voice and speed";

  const cover = $("coverBox");
  if (book.hasCover) {
    cover.style.backgroundImage = `url("/api/books/${book.bookId}/cover")`;
    cover.innerHTML = "";
  } else {
    cover.style.backgroundImage = "";
    cover.innerHTML = "<span>EPUB</span>";
  }

  const content = book.chapters.filter((c) => c.chars >= 150 && !c.isFrontMatter && c.linear);
  state.selected = new Set((content.length ? content : book.chapters).map((c) => c.index));
  renderChapters();
}

function renderChapters() {
  const filter = $("chapterFilter").value.trim().toLowerCase();
  const list = $("chapterList");
  list.innerHTML = "";

  state.chapters
    .filter((c) => !filter || c.title.toLowerCase().includes(filter))
    .forEach((chapter) => {
      const row = document.createElement("label");
      row.className = "chapter"
        + (chapter.isFrontMatter ? " front" : "")
        + (chapter.chars < 40 ? " empty" : "");
      row.innerHTML = `
        <input type="checkbox" ${state.selected.has(chapter.index) ? "checked" : ""} />
        <span class="num">${chapter.index + 1}</span>
        <span class="title" title="${chapter.title.replace(/"/g, "&quot;")}">${chapter.title}</span>
        <span class="len">${chapter.chars ? chapter.estimateLabel : "empty"}</span>`;
      row.querySelector("input").addEventListener("change", (event) => {
        if (event.target.checked) state.selected.add(chapter.index);
        else state.selected.delete(chapter.index);
        updateSelection();
      });
      list.appendChild(row);
    });
  updateSelection();
}

function updateSelection() {
  const chosen = state.chapters.filter((c) => state.selected.has(c.index));
  const ms = chosen.reduce((sum, c) => sum + c.estimateMs, 0);
  $("selectedNote").textContent = chosen.length
    ? `${chosen.length} chapter${chosen.length === 1 ? "" : "s"} selected · about ${fmtDuration(ms)} of audio`
    : "No chapters selected";

  const ready = chosen.length > 0 && !!state.voice;
  $("buildBtn").disabled = !ready;
  $("buildHint").textContent = !chosen.length
    ? "Select at least one chapter"
    : !state.voice ? "Choose a voice" : "";
}

function wireConfigure() {
  $("changeBook").addEventListener("click", reset);
  $("newBookBtn").addEventListener("click", reset);
  $("chapterFilter").addEventListener("input", renderChapters);

  document.querySelectorAll("[data-select]").forEach((button) => {
    button.addEventListener("click", () => {
      const mode = button.dataset.select;
      if (mode === "all") state.selected = new Set(state.chapters.map((c) => c.index));
      if (mode === "none") state.selected = new Set();
      if (mode === "content") {
        state.selected = new Set(
          state.chapters.filter((c) => c.chars >= 150 && !c.isFrontMatter && c.linear).map((c) => c.index)
        );
      }
      renderChapters();
    });
  });

  document.querySelectorAll("#modeGroup .seg").forEach((button) => {
    button.addEventListener("click", () => {
      document.querySelectorAll("#modeGroup .seg").forEach((b) => b.classList.remove("active"));
      button.classList.add("active");
      state.mode = button.dataset.mode;
    });
  });

  document.querySelectorAll("#engineGroup .seg").forEach((button) => {
    button.addEventListener("click", () => selectEngine(button.dataset.engine));
  });

  $("rate").addEventListener("input", () => {
    $("rateValue").textContent = `${$("rate").value}%`;
  });
  $("pitch").addEventListener("input", () => {
    $("pitchValue").textContent = `${$("pitch").value} Hz`;
  });
  $("voiceSearch").addEventListener("input", renderVoices);

  $("buildBtn").addEventListener("click", build);
  $("cancelBtn").addEventListener("click", async () => {
    if (!state.jobId) return;
    try { await api(`/api/jobs/${state.jobId}/cancel`, { method: "POST" }); } catch { /* already finished */ }
  });

  wireModelUpload();
}

function reset() {
  state.book = null;
  state.chapters = [];
  state.selected = new Set();
  state.jobId = null;
  if (state.timer) clearInterval(state.timer);
  $("fileInput").value = "";
  $("uploadError").hidden = true;
  $("chapterFilter").value = "";
  show("stepUpload");
  loadHistory();
}

/* ----------------------------------------------------------------- engines */
async function loadEngines() {
  try {
    const data = await api("/api/engines");
    state.engines = data.engines;
    for (const engine of data.engines) {
      const button = document.querySelector(`#engineGroup .seg[data-engine="${engine.id}"]`);
      if (!button) continue;
      button.disabled = false;
      button.querySelector("small").textContent = engine.available
        ? engine.description.split(".")[0]
        : engine.detail || "not available";
    }
    const local = data.engines.find((e) => e.id === "local");
    if (local && !local.available) {
      const button = document.querySelector('#engineGroup .seg[data-engine="local"]');
      if (button) button.classList.add("warn");
    }
  } catch { /* keep cloud only */ }
  await selectEngine("edge");
}

async function selectEngine(engineId) {
  state.engine = engineId;
  document.querySelectorAll("#engineGroup .seg").forEach((button) => {
    button.classList.toggle("active", button.dataset.engine === engineId);
  });
  const local = engineId === "local" || engineId === "pocket";
  $("localModels").hidden = !local;
  $("cloneDrop").hidden = engineId !== "pocket";
  $("modelDrop").querySelector("strong").textContent = engineId === "pocket"
    ? "Add a Pocket TTS model (.onnx)"
    : "Add an ONNX voice";
  $("modelDrop").querySelector("span").textContent = engineId === "pocket"
    ? "one self-contained file, voices included"
    : "pick the .onnx and its .onnx.json together";
  // Pitch only exists in the cloud engine; say so instead of pretending.
  const hasPitch = engineId === "edge";
  $("pitch").disabled = !hasPitch;
  $("pitch").title = hasPitch ? "" : "This engine has no pitch control";
  $("pitch").parentElement.style.opacity = hasPitch ? "1" : "0.45";
  $("engineHint").textContent = engineId === "local"
    ? "Runs on this machine. No network, no quota. Speed depends on your CPU."
    : engineId === "pocket"
      ? "Runs on this machine. One .onnx carries the model and its voices; clone more from a short recording."
      : "Needs an internet connection. Nothing is uploaded but the text being read.";

  await loadVoices(engineId);
}

async function loadVoices(engineId) {
  const select = $("voiceSelect");
  select.innerHTML = `<option value="">loading…</option>`;
  try {
    const data = await api(`/api/engines/${engineId}/voices`);
    state.voices = data.voices || [];
    state.presets = data.presets || [];
    if (engineId === "local" || engineId === "pocket") {
      $("modelStatus").textContent = state.voices.length
        ? `${state.voices.length} local voice${state.voices.length === 1 ? "" : "s"} ready`
        : data.detail || "No local voice yet — add one above";
    }
    renderVoices();
  } catch (err) {
    select.innerHTML = `<option value="">${err.message}</option>`;
    state.voices = [];
    state.voice = null;
    updateSelection();
  }
}

function renderVoices() {
  const select = $("voiceSelect");
  const query = $("voiceSearch").value.trim().toLowerCase();
  const previous = state.voice;
  select.innerHTML = "";

  const presets = (state.presets || []).filter((p) => !query
    || p.label.toLowerCase().includes(query) || p.id.toLowerCase().includes(query));
  const voices = state.voices.filter((v) => !query
    || (v.label || "").toLowerCase().includes(query)
    || (v.id || "").toLowerCase().includes(query)
    || (v.locale || "").toLowerCase().includes(query));

  if (presets.length) {
    const group = document.createElement("optgroup");
    group.label = state.engine === "edge" ? "Recommended" : "Installed voices";
    presets.forEach((preset) => group.appendChild(optionFor(preset)));
    select.appendChild(group);
  }

  const byLocale = new Map();
  voices.forEach((voice) => {
    const locale = voice.locale || "other";
    if (!byLocale.has(locale)) byLocale.set(locale, []);
    byLocale.get(locale).push(voice);
  });
  [...byLocale.keys()].sort().forEach((locale) => {
    const group = document.createElement("optgroup");
    group.label = locale;
    byLocale.get(locale).forEach((voice) => group.appendChild(optionFor(voice)));
    select.appendChild(group);
  });

  if (!select.options.length) {
    const empty = document.createElement("option");
    empty.value = "";
    empty.textContent = state.engine === "local" ? "No local voice yet" : "No voice matched";
    select.appendChild(empty);
  }

  const keep = previous && [...select.options].some((o) => o.value === previous)
    ? previous
    : select.options[0] && select.options[0].value;
  select.value = keep || "";
  state.voice = select.value || null;
  select.onchange = () => { state.voice = select.value || null; updateSelection(); };
  updateSelection();
}

function optionFor(voice) {
  const option = document.createElement("option");
  option.value = voice.id;
  option.textContent = voice.label || voice.id;
  return option;
}

function wireModelUpload() {
  const zone = $("modelDrop");
  const input = $("modelInput");
  if (!zone || !input) return;

  zone.addEventListener("click", () => input.click());
  zone.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") { event.preventDefault(); input.click(); }
  });
  input.addEventListener("change", () => uploadModel([...input.files]));

  const cloneZone = $("cloneDrop");
  const cloneInput = $("cloneInput");
  cloneZone.addEventListener("click", () => cloneInput.click());
  cloneZone.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") { event.preventDefault(); cloneInput.click(); }
  });
  cloneInput.addEventListener("change", () => {
    if (cloneInput.files && cloneInput.files[0]) cloneVoice(cloneInput.files[0]);
  });
}

async function uploadModel(files) {
  const status = $("modelStatus");
  const engine = state.engine === "pocket" ? "pocket" : "local";
  const onnx = files.find((f) => f.name.toLowerCase().endsWith(".onnx"));
  const json = files.find((f) => f.name.toLowerCase().endsWith(".json"));
  if (!onnx) { status.textContent = "Pick the model's .onnx file."; return; }
  if (engine === "local" && !json) {
    status.textContent = "A Piper voice also needs its .onnx.json — or switch to Pocket TTS.";
    return;
  }

  status.textContent = engine === "pocket"
    ? `Adding ${onnx.name}… this can take a minute, the file is large.`
    : `Adding ${onnx.name}…`;
  const form = new FormData();
  form.append("model", onnx);
  if (json) form.append("modelConfig", json);
  try {
    const data = await api(`/api/engines/${engine}/models`, { method: "POST", body: form });
    const target = data.engine || engine;
    status.textContent = `${onnx.name} added${data.voices ? ` — ${data.voices.length} voice${data.voices.length === 1 ? "" : "s"}` : ""}.`;
    if (target !== state.engine) await selectEngine(target);
    else await loadVoices(target);
  } catch (err) {
    status.textContent = `Could not add it: ${err.message}`;
  } finally {
    $("modelInput").value = "";
  }
}

async function cloneVoice(file) {
  const status = $("cloneStatus");
  const current = state.voice || "";
  const model = current.includes("::") ? current.split("::")[0]
    : (state.voices[0] && state.voices[0].model) || "";
  if (!model) { status.textContent = "Add a Pocket TTS model first."; return; }

  const name = file.name.replace(/\.[^.]+$/, "").replace(/[^\w-]+/g, "-").slice(0, 40) || "cloned";
  status.textContent = `Cloning from ${file.name}…`;
  const form = new FormData();
  form.append("model", model);
  form.append("name", name);
  form.append("sample", file);
  try {
    await api("/api/engines/pocket/clones", { method: "POST", body: form });
    status.textContent = `Cloned "${name}". Pick it in the voice list.`;
    await loadVoices("pocket");
  } catch (err) {
    status.textContent = `Could not clone: ${err.message}`;
  } finally {
    $("cloneInput").value = "";
  }
}

/* ------------------------------------------------------------------- build */
async function build() {
  const chapters = [...state.selected];
  if (!chapters.length || !state.voice) return;

  const body = {
    bookId: state.book.bookId,
    chapters,
    engine: state.engine,
    voice: state.voice,
    rate: Number($("rate").value),
    pitch: Number($("pitch").value),
    mode: state.mode,
    bitrate: Number($("bitrate").value),
    concurrency: Number($("concurrency").value),
    chapterGapMs: Number($("chapterGap").value),
    narratorLabel: $("narratorLabel").value || "LexiVoice Studio",
  };

  show("stepRunning");
  $("runTitle").textContent = `Building “${state.book.title}”`;
  $("progressBar").style.width = "0%";
  $("progressPct").textContent = "0%";
  $("progressMsg").textContent = "Queued…";
  $("chapterNow").textContent = "";
  $("logList").innerHTML = "";
  $("cancelBtn").hidden = false;

  try {
    const job = await api("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    state.jobId = job.id;
    poll();
    state.timer = setInterval(poll, 1500);
  } catch (err) {
    $("progressMsg").textContent = err.message;
    $("progressBar").style.width = "100%";
    $("progressBar").style.background = "var(--danger)";
  }
}

async function poll() {
  if (!state.jobId) return;
  let job;
  try { job = await api(`/api/jobs/${state.jobId}`); } catch { return; }

  const pct = Math.round((job.fraction || 0) * 100);
  $("progressBar").style.width = `${pct}%`;
  $("progressPct").textContent = `${pct}%`;
  $("progressMsg").textContent = job.message || job.stage;
  if (job.chapter) {
    $("chapterNow").textContent = job.chapterPosition
      ? `${job.chapterPosition} of ${job.chapterCount} · ${job.chapter}`
      : job.chapter;
  }
  if (job.log && job.log.length) {
    $("logList").innerHTML = job.log.map((line) => `<li>${escapeHtml(line)}</li>`).join("");
    $("logList").scrollTop = $("logList").scrollHeight;
  }

  if (job.status === "done") {
    clearInterval(state.timer);
    state.timer = null;
    renderDone(job);
  } else if (job.status === "error" || job.status === "cancelled") {
    clearInterval(state.timer);
    state.timer = null;
    $("progressMsg").textContent = job.status === "cancelled" ? "Stopped." : `Failed: ${job.error || job.message}`;
    $("cancelBtn").hidden = true;
    $("runTitle").textContent = job.status === "cancelled" ? "Stopped" : "That build failed";
  }
}

function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, (ch) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]
  ));
}

/* -------------------------------------------------------------------- done */
function renderDone(job) {
  const result = job.result;
  show("stepDone");
  $("doneSummary").textContent =
    `${result.bookTitle} — ${result.chapters} chapter${result.chapters === 1 ? "" : "s"}, ${result.durationLabel} of audio, `
    + `${result.mode === "m4b" ? "one chaptered .m4b" : "one .mp3 per chapter"} with a matching sync_map.json.`;

  const zip = result.outputs.find((o) => o.kind === "zip");
  const link = $("downloadZip");
  if (zip) {
    link.href = `/api/jobs/${job.id}/files/${encodeURIComponent(zip.name)}`;
    link.textContent = `Download bundle (.zip · ${fmtBytes(zip.bytes)})`;
    link.hidden = false;
  } else {
    link.hidden = true;
  }

  $("fileList").innerHTML = result.outputs
    .filter((o) => o.kind !== "zip")
    .map((o) => `<a class="file-chip" href="/api/jobs/${job.id}/files/${encodeURIComponent(o.name)}">
        ${escapeHtml(o.name)} <span>${fmtBytes(o.bytes)}</span></a>`)
    .join("");

  const verify = result.verify || { checks: [], problems: [], warnings: [] };
  const ok = verify.ok;
  $("verifyBox").className = `verify${ok ? "" : " bad"}`;
  const lines = [
    `<b>${ok ? "Verified" : "Needs a look"}</b> — read back the way LexiVoice reads it.`,
    `<ul>${(verify.checks || []).map((c) => `<li>${escapeHtml(c)}</li>`).join("")}`,
    (verify.problems || []).map((p) => `<li>${escapeHtml(p)}</li>`).join(""),
    (verify.warnings || []).map((w) => `<li class="muted">${escapeHtml(w)}</li>`).join(""),
    `</ul>`,
  ];
  if (result.failures && result.failures.length) {
    lines.push(`<p class="hint">${result.failures.length} chunk(s) failed and were replaced with silence: ${escapeHtml(result.failures[0])}</p>`);
  }
  $("verifyBox").innerHTML = lines.join("");
}

/* ----------------------------------------------------------------- history */
async function loadHistory() {
  try {
    const data = await api("/api/jobs");
    const jobs = data.jobs || [];
    if (!jobs.length) { $("historyCard").hidden = true; return; }
    $("historyCard").hidden = false;
    $("historyList").innerHTML = jobs.slice(0, 8).map((job) => {
      const zip = (job.files || []).find((f) => f.kind === "zip");
      const when = new Date((job.updatedAt || job.createdAt) * 1000).toLocaleString();
      return `<div class="hrow">
        <span class="status-dot ${job.status}"></span>
        <span class="grow">${escapeHtml(job.bookTitle || "Untitled")}</span>
        <span class="muted">${job.status}${job.result ? ` · ${job.result.durationLabel}` : ""}</span>
        <span class="muted">${when}</span>
        ${zip ? `<a class="ghost-btn" href="${zip.url}">Download</a>` : ""}
      </div>`;
    }).join("");
  } catch { /* history is optional */ }
}

init();
