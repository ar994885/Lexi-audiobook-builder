"""LexiVoice Studio — turn an EPUB into an audiobook your phone already reads."""
from .config import VERSION, BUILD_STAMP

__all__ = ["VERSION", "BUILD_STAMP"]
