"""Job queue: one conversion at a time, progress the browser can poll."""
from __future__ import annotations

import asyncio
import json
import time
import traceback
import uuid
from pathlib import Path

from . import config
from .pipeline import Cancelled, run_job

TERMINAL = {"done", "error", "cancelled"}


class JobManager:
    def __init__(self) -> None:
        self.queue: asyncio.Queue[str] = asyncio.Queue()
        self.jobs: dict[str, dict] = {}
        self.cancel_events: dict[str, asyncio.Event] = {}
        self._workers: list[asyncio.Task] = []
        self._loaded = False

    # ---------------------------------------------------------------- storage
    def job_dir(self, job_id: str) -> Path:
        return config.JOBS_DIR / job_id

    def _state_path(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "job.json"

    def _persist(self, job: dict) -> None:
        path = self._state_path(job["id"])
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(job, fh, ensure_ascii=False, indent=2)
        tmp.replace(path)

    def load_existing(self) -> None:
        """Pick up jobs from earlier runs (finished ones stay downloadable)."""
        if self._loaded:
            return
        self._loaded = True
        if not config.JOBS_DIR.exists():
            return
        for directory in sorted(config.JOBS_DIR.iterdir()):
            state = directory / "job.json"
            if not state.is_file():
                continue
            try:
                with open(state, "r", encoding="utf-8") as fh:
                    job = json.load(fh)
            except Exception:
                continue
            if job.get("status") in ("queued", "running"):
                job["status"] = "error"
                job["error"] = "Interrupted by a server restart. Start the conversion again."
            self.jobs[job["id"]] = job

    # ------------------------------------------------------------------- api
    def create(self, book_id: str, book_title: str, options: dict) -> dict:
        job_id = uuid.uuid4().hex[:12]
        job = {
            "id": job_id,
            "bookId": book_id,
            "bookTitle": book_title,
            "status": "queued",
            "stage": "queued",
            "fraction": 0.0,
            "message": "Waiting in the queue",
            "createdAt": time.time(),
            "updatedAt": time.time(),
            "options": options,
            "chapter": None,
            "result": None,
            "error": None,
            "log": [],
        }
        self.jobs[job_id] = job
        self.cancel_events[job_id] = asyncio.Event()
        self._persist(job)
        self.queue.put_nowait(job_id)
        return job

    def get(self, job_id: str) -> dict | None:
        return self.jobs.get(job_id)

    def list(self) -> list[dict]:
        return sorted(self.jobs.values(), key=lambda j: j["createdAt"], reverse=True)

    def cancel(self, job_id: str) -> bool:
        job = self.jobs.get(job_id)
        if not job or job["status"] in TERMINAL:
            return False
        event = self.cancel_events.get(job_id)
        if event:
            event.set()
        if job["status"] == "queued":
            job["status"] = "cancelled"
            job["stage"] = "cancelled"
            job["message"] = "Cancelled"
            self._persist(job)
        return True

    def update(self, job: dict, **changes) -> None:
        job.update(changes)
        job["updatedAt"] = time.time()
        self._persist(job)

    def log(self, job: dict, message: str) -> None:
        entry = {"at": time.time(), "message": message}
        job.setdefault("log", []).append(entry)
        job["log"] = job["log"][-80:]

    # ---------------------------------------------------------------- workers
    def start(self, loop: asyncio.AbstractEventLoop | None = None) -> None:
        self.load_existing()
        for _ in range(config.MAX_JOBS_IN_FLIGHT):
            self._workers.append(asyncio.create_task(self._worker()))

    async def stop(self) -> None:
        for worker in self._workers:
            worker.cancel()
        self._workers.clear()

    async def _worker(self) -> None:
        while True:
            job_id = await self.queue.get()
            try:
                await self._run(job_id)
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001 - never let a worker die
                traceback.print_exc()
            finally:
                self.queue.task_done()

    async def _run(self, job_id: str) -> None:
        job = self.jobs.get(job_id)
        if not job or job["status"] in TERMINAL:
            return
        cancel_event = self.cancel_events[job_id]
        self.update(job, status="running", stage="starting", message="Opening the book", fraction=0.01)
        self.log(job, f"Started: {job['bookTitle']}")

        def progress(**kw):
            stage = kw.pop("stage", None)
            fraction = kw.pop("fraction", None)
            message = kw.pop("message", None)
            if stage:
                job["stage"] = stage
            if fraction is not None:
                job["fraction"] = max(0.0, min(1.0, float(fraction)))
            if message:
                job["message"] = message
            for key, value in kw.items():
                if key == "chapterTitle":
                    job["chapter"] = value
                elif key == "chapterPosition":
                    job["chapterPosition"] = value
                elif key == "chapterCount":
                    job["chapterCount"] = value
                elif key == "chapterIndex":
                    job["chapterIndex"] = value
            job["updatedAt"] = time.time()
            self._persist(job)

        try:
            result = await run_job(
                self.job_dir(job_id),
                config.BOOKS_DIR / job["bookId"],
                job["options"],
                progress,
                cancel_event.is_set,
            )
            self.update(job, status="done", stage="done", fraction=1.0,
                        message=f"Finished — {result['durationLabel']}", result=result)
            self.log(job, f"Done: {result['durationLabel']}, {len(result['outputs'])} files")
        except Cancelled:
            self.update(job, status="cancelled", stage="cancelled", message="Cancelled")
            self.log(job, "Cancelled by you")
        except Exception as exc:  # noqa: BLE001 - shown to the user
            message = f"{type(exc).__name__}: {exc}"
            self.update(job, status="error", stage="error", message=message, error=message)
            self.log(job, f"Failed: {message}")
            traceback.print_exc()
        finally:
            self.cancel_events.pop(job_id, None)


manager = JobManager()
