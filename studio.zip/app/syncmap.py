"""The `sync_map.json` LexiVoice reads next to an audiobook.

Schema is the app's ``BookSyncMap`` (see ``SyncAlignmentModels.kt``). Sentence
offsets are relative to the start of their chapter; the app builds absolute
times by adding each chapter's ``durationMs`` in order — which is why the
per-chapter duration we write includes the gap that follows the chapter in the
compiled M4B.
"""
from __future__ import annotations

import json
from pathlib import Path

NARRATOR_LABEL = "LexiVoice Studio"


def build(
    *,
    book_title: str,
    author: str,
    narrator: str,
    year: str,
    genre: str,
    source_epub: str,
    chapters: list[dict],
) -> dict:
    """`chapters` items: chapterIndex, title, fileName, durationMs, sentences[]."""
    payload_chapters = []
    for chapter in chapters:
        payload_chapters.append({
            "chapterIndex": int(chapter["chapterIndex"]),
            "title": chapter["title"],
            "fileName": chapter["fileName"],
            "fileUri": "",
            "durationMs": int(chapter["durationMs"]),
            "isDirectPath": False,
            "sentences": [
                {
                    "sentenceIndex": int(s["sentenceIndex"]),
                    "text": s["text"],
                    "offsetMs": int(round(s["offsetMs"])),
                    "endOffsetMs": int(round(s["endOffsetMs"])),
                }
                for s in chapter["sentences"]
            ],
        })

    return {
        "bookTitle": book_title,
        "author": author or "Unknown Author",
        "narrator": narrator or NARRATOR_LABEL,
        "year": year,
        "genre": genre,
        "coverPath": None,
        "sourceEpubKey": source_epub,
        "sourceEpubIsDirect": False,
        "chapters": payload_chapters,
    }


def write(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)
    tmp.replace(path)


def flatten(sync_map: dict) -> list[dict]:
    """Port of `SyncAlignmentSerializer.flattenToTimeline` — absolute sentence times."""
    segments = []
    cursor = 0
    for chapter in sorted(sync_map["chapters"], key=lambda c: c["chapterIndex"]):
        duration = max(100, int(chapter["durationMs"]))
        for sentence in chapter["sentences"]:
            start = cursor + int(sentence["offsetMs"])
            end = max(cursor + int(sentence["endOffsetMs"]), start + 50)
            segments.append({
                "chapterIndex": chapter["chapterIndex"],
                "sentenceIndex": sentence["sentenceIndex"],
                "text": sentence["text"],
                "startMs": start,
                "endMs": end,
            })
        cursor += duration
    return segments


def validate(payload: dict) -> list[str]:
    """Return a list of problems that would break the app's read-along."""
    problems = []
    if not payload.get("bookTitle"):
        problems.append("bookTitle is empty")
    seen = set()
    last_index = -10
    for chapter in payload["chapters"]:
        index = chapter["chapterIndex"]
        if index in seen:
            problems.append(f"duplicate chapterIndex {index}")
        seen.add(index)
        if index <= last_index:
            problems.append(f"chapterIndex {index} is out of order")
        last_index = index
        if chapter["durationMs"] <= 0:
            problems.append(f"chapter {index} has no duration")
        previous_end = -1
        for sentence in chapter["sentences"]:
            if sentence["endOffsetMs"] < sentence["offsetMs"]:
                problems.append(f"chapter {index} sentence {sentence['sentenceIndex']} ends before it starts")
            if sentence["offsetMs"] < previous_end - 250:
                problems.append(f"chapter {index} sentence {sentence['sentenceIndex']} overlaps the previous one")
            previous_end = sentence["endOffsetMs"]
            if sentence["endOffsetMs"] > chapter["durationMs"] + 250:
                problems.append(f"chapter {index} sentence {sentence['sentenceIndex']} runs past the chapter")
    return problems
