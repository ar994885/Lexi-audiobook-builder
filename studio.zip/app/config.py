"""Runtime configuration for LexiVoice Studio."""
from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

VERSION = "1.2.6"
BUILD_STAMP = "2026-11-26 17:05 IST"

DATA_DIR = Path(os.environ.get("LEXIVOICE_DATA_DIR", BASE_DIR / "data")).resolve()
BOOKS_DIR = DATA_DIR / "books"
JOBS_DIR = DATA_DIR / "jobs"
WEB_DIR = BASE_DIR / "web"

# Local ONNX voices live here (Piper layout: <name>/<name>.onnx + .onnx.json).
MODELS_DIR = Path(os.environ.get("LEXIVOICE_MODELS_DIR", BASE_DIR / "models")).resolve()

# Optional outbound proxy for the TTS websocket (corporate networks).
TTS_PROXY = os.environ.get("LEXIVOICE_PROXY") or None
# Optional CA bundle (only needed behind a TLS-intercepting proxy).
CA_BUNDLE = os.environ.get("LEXIVOICE_CA_BUNDLE") or None

# How many books are converted at the same time.
MAX_JOBS_IN_FLIGHT = max(1, int(os.environ.get("LEXIVOICE_MAX_JOBS", "1")))

# Host/port for `python -m app`.
HOST = os.environ.get("LEXIVOICE_HOST", "0.0.0.0")
PORT = int(os.environ.get("LEXIVOICE_PORT") or os.environ.get("PORT") or "8000")

MAX_UPLOAD_BYTES = int(os.environ.get("LEXIVOICE_MAX_UPLOAD_MB", "200")) * 1024 * 1024

for _d in (BOOKS_DIR, JOBS_DIR, DATA_DIR / "voices", MODELS_DIR):
    _d.mkdir(parents=True, exist_ok=True)
