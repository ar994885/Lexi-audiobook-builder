"""The conversion pipeline: EPUB -> speech -> M4B (or MP3) + sync_map.json.

Two synthesis shapes, chosen by the engine:

* chunk engines (edge-tts) get runs of whole sentences and report the timing of
  each sentence they spoke;
* sentence engines (local ONNX voices) get one sentence at a time, so timings
  are exact by construction.

Either way, the sentence indices and texts written to ``sync_map.json`` are the
ones the LexiVoice app computes for that EPUB chapter.
"""
from __future__ import annotations

import asyncio
import shutil
import zipfile
from pathlib import Path

from . import audio, config, engines, mp4tags, syncmap
from .engines import EngineError
from .epubbook import chapter_blocks_from_zip, load_book, zip_names
from .text import human_duration, sanitize_for_tts, slugify

DEFAULT_CHUNK_CHARS = 900
DEFAULT_CHUNK_GAP_MS = 120
DEFAULT_SENTENCE_GAP_MS = 70
DEFAULT_CHAPTER_GAP_MS = 900


class Cancelled(RuntimeError):
    pass


# --------------------------------------------------------------------------
# chunking
# --------------------------------------------------------------------------

def build_chunks(chapter: dict, max_chars: int = DEFAULT_CHUNK_CHARS) -> list[dict]:
    """Group a chapter's sentences into speech-sized chunks."""
    sentences = [s for block in chapter["blocks"] for s in block["sentences"]]
    chunks: list[dict] = []
    current: list[dict] = []
    current_len = 0

    for sentence in sentences:
        text = sanitize_for_tts(sentence["text"])
        if not text:
            continue
        if len(text) > max_chars:
            if current:
                chunks.append({"sentences": current, "text": " ".join(s["tts"] for s in current)})
                current, current_len = [], 0
            words = text.split(" ")
            piece: list[str] = []
            piece_len = 0
            for word in words:
                if piece_len + len(word) + 1 > max_chars and piece:
                    chunks.append({
                        "sentences": [{"index": sentence["index"], "text": sentence["text"], "tts": " ".join(piece)}],
                        "text": " ".join(piece),
                    })
                    piece, piece_len = [], 0
                piece.append(word)
                piece_len += len(word) + 1
            if piece:
                chunks.append({
                    "sentences": [{"index": sentence["index"], "text": sentence["text"], "tts": " ".join(piece)}],
                    "text": " ".join(piece),
                })
            continue

        if current_len + len(text) + 1 > max_chars and current:
            chunks.append({"sentences": current, "text": " ".join(s["tts"] for s in current)})
            current, current_len = [], 0
        current.append({"index": sentence["index"], "text": sentence["text"], "tts": text})
        current_len += len(text) + 1

    if current:
        chunks.append({"sentences": current, "text": " ".join(s["tts"] for s in current)})
    return chunks


def sentence_list(chapter: dict) -> list[dict]:
    out = []
    for block in chapter["blocks"]:
        for sentence in block["sentences"]:
            out.append(sentence)
    return out


# --------------------------------------------------------------------------
# alignment
# --------------------------------------------------------------------------

def _norm(text: str) -> str:
    return "".join(ch for ch in text.lower() if ch.isalnum())


def align_sentences(sentence_texts: list[str], boundaries: list[dict],
                    chunk_start_ms: float, chunk_audio_ms: float) -> list[tuple[float, float]]:
    """Map the service's sentence boundaries onto our sentence texts."""
    count = len(sentence_texts)
    if count == 0:
        return []

    def proportional() -> list[tuple[float, float]]:
        lengths = [max(1, len(_norm(t))) for t in sentence_texts]
        total = sum(lengths)
        result = []
        cursor = 0.0
        for length in lengths:
            span = chunk_audio_ms * length / total
            result.append((chunk_start_ms + cursor, chunk_start_ms + cursor + span))
            cursor += span
        return result

    if not boundaries:
        return proportional()

    if len(boundaries) == count:
        starts = [b["offsetMs"] for b in boundaries]
        ends = [b["offsetMs"] + b["durationMs"] for b in boundaries]
        matches = sum(
            1 for text, boundary in zip(sentence_texts, boundaries)
            if _norm(text)[:25] and _norm(text)[:25] in _norm(boundary["text"])
        )
        if matches >= max(1, int(count * 0.4)):
            out = []
            for i in range(count):
                start = chunk_start_ms + starts[i]
                end = chunk_start_ms + max(ends[i], starts[i] + 50)
                out.append((start, min(end, chunk_start_ms + chunk_audio_ms + 50)))
            return out
        return proportional()

    # The service split or merged something: consume boundaries greedily.
    out: list[tuple[float, float]] = []
    index = 0
    for text in sentence_texts:
        target = max(1, len(_norm(text)))
        first = None
        last = None
        covered = 0
        while index < len(boundaries) and covered < target * 0.85:
            boundary = boundaries[index]
            covered += max(1, len(_norm(boundary["text"])))
            if first is None:
                first = boundary
            last = boundary
            index += 1
        if first is None or last is None:
            return proportional()
        start = chunk_start_ms + first["offsetMs"]
        end = chunk_start_ms + last["offsetMs"] + last["durationMs"]
        out.append((start, min(max(end, start + 50), chunk_start_ms + chunk_audio_ms + 50)))

    if index < len(boundaries) and out:
        last_boundary = boundaries[-1]
        out[-1] = (out[-1][0], chunk_start_ms + last_boundary["offsetMs"] + last_boundary["durationMs"])
    return out


# --------------------------------------------------------------------------
# chapter synthesis
# --------------------------------------------------------------------------

async def _synthesize_sentences(
    engine, chapter, options, semaphore, writer, progress, cancelled
) -> tuple[dict[int, tuple[float, float]], list[str], float]:
    """Exact per-sentence timing: one request per sentence."""
    sentences = sentence_list(chapter)
    gap_ms = float(options.get("sentenceGapMs", DEFAULT_SENTENCE_GAP_MS))
    concurrency = max(1, int(options.get("concurrency", 3)))
    times: dict[int, tuple[float, float]] = {}
    failures: list[str] = []
    cursor_ms = 0.0
    total = len(sentences) or 1
    done = 0

    async def run(sentence: dict):
        async with semaphore:
            text = sanitize_for_tts(sentence["text"]) or sentence["text"]
            return await engine.synthesize(text, options["voice"], options.get("rate", 0.0), options.get("pitch", 0.0))

    batch_size = max(1, concurrency)
    for start in range(0, len(sentences), batch_size):
        if cancelled():
            raise Cancelled()
        batch = sentences[start:start + batch_size]
        results = await asyncio.gather(*(run(s) for s in batch), return_exceptions=True)

        for sentence, result in zip(batch, results):
            if isinstance(result, Exception):
                failures.append(f"{type(result).__name__}: {result}")
                estimated = max(400.0, len(sentence["text"]) / 14.0 * 1000)
                times[sentence["index"]] = (cursor_ms, cursor_ms + estimated)
                writer.write_silence(estimated)
                cursor_ms += estimated
            else:
                pcm = await asyncio.to_thread(audio.resample, result.pcm, result.sample_rate)
                if pcm.size == 0:
                    continue
                span = pcm.size * 1000.0 / audio.SAMPLE_RATE
                times[sentence["index"]] = (cursor_ms, cursor_ms + span)
                writer.write(pcm)
                cursor_ms += span
                writer.write_silence(gap_ms)
                cursor_ms += gap_ms
            done += 1
            progress(fraction=done / total, message=f"{done} of {total} sentences spoken")
    return times, failures, cursor_ms


async def _synthesize_chunks(
    engine, chapter, options, semaphore, writer, progress, cancelled
) -> tuple[dict[int, tuple[float, float]], list[str], float]:
    """Speak the chapter in chunks, in text order, reporting as each one lands.

    Chunks are dispatched several at a time but written strictly in order: the
    audio must follow the book, while the page should still hear about the first
    finished chunk within seconds.
    """
    chunks = build_chunks(chapter, options.get("chunkChars", DEFAULT_CHUNK_CHARS))
    chunk_gap = float(options.get("chunkGapMs", DEFAULT_CHUNK_GAP_MS))
    concurrency = max(1, int(options.get("concurrency", 3)))
    window = max(2, concurrency * 2)

    times: dict[int, tuple[float, float]] = {}
    failures: list[str] = []
    cursor_ms = 0.0
    total_chars = sum(len(c["text"]) for c in chunks) or 1
    received_chars = 0
    written_chars = 0

    async def run(chunk: dict):
        async with semaphore:
            return await engine.synthesize(chunk["text"], options["voice"],
                                           options.get("rate", 0.0), options.get("pitch", 0.0))

    async def guarded(chunk: dict):
        try:
            return chunk, await run(chunk), None
        except Exception as exc:  # noqa: BLE001 - reported per chunk
            return chunk, None, exc

    pending: dict[asyncio.Task, int] = {}
    results: dict[int, tuple[dict, object, Exception | None]] = {}
    next_index = 0

    def dispatch() -> None:
        while len(pending) < window and next_index + len(pending) + len(results) < len(chunks):
            index = next_index + len(pending) + len(results)
            if index >= len(chunks):
                break
            pending[asyncio.create_task(guarded(chunks[index]))] = index

    dispatch()

    while next_index < len(chunks):
        if cancelled():
            for task in pending:
                task.cancel()
            raise Cancelled()
        if not pending:
            break
        done, _ = await asyncio.wait(list(pending), return_when=asyncio.FIRST_COMPLETED)
        for task in done:
            index = pending.pop(task)
            chunk, result, error = task.result()
            results[index] = (chunk, result, error)
            received_chars += len(chunk["text"])

        # Written strictly in order; a chunk that has not arrived yet blocks the
        # queue rather than being skipped.
        while next_index in results:
            chunk, result, error = results.pop(next_index)
            next_index += 1

            if error is not None:
                if not written_chars and not times:
                    raise EngineError(
                        f"the speech service refused the first request: {error}"
                    ) from error
                failures.append(f"{type(error).__name__}: {error}")
                estimated = max(500.0, len(chunk["text"]) / 14.0 * 1000)
                for sentence in chunk["sentences"]:
                    times.setdefault(sentence["index"], (cursor_ms, cursor_ms + estimated))
                writer.write_silence(estimated)
                cursor_ms += estimated
                written_chars += len(chunk["text"])
                continue

            pcm = await asyncio.to_thread(audio.resample, result.pcm, result.sample_rate)
            if pcm.size == 0:
                continue
            chunk_ms = pcm.size * 1000.0 / audio.SAMPLE_RATE
            mapped = align_sentences(
                [s["text"] for s in chunk["sentences"]],
                result.boundaries,
                cursor_ms,
                chunk_ms,
            )
            for sentence, (start_ms, end_ms) in zip(chunk["sentences"], mapped):
                previous = times.get(sentence["index"])
                if previous is None:
                    times[sentence["index"]] = (start_ms, end_ms)
                else:
                    times[sentence["index"]] = (previous[0], max(previous[1], end_ms))

            writer.write(pcm)
            cursor_ms += chunk_ms
            written_chars += len(chunk["text"])

            if next_index < len(chunks):
                writer.write_silence(chunk_gap)
                cursor_ms += chunk_gap

        dispatch()
        progress(
            fraction=min(0.99, received_chars / total_chars),
            message=f"{received_chars:,} of {total_chars:,} characters spoken",
        )

    for task in pending:
        task.cancel()
    return times, failures, cursor_ms


async def synthesize_chapter(
    engine, chapter: dict, options: dict, semaphore: asyncio.Semaphore,
    wav_path: Path, progress, cancelled,
) -> dict:
    writer = audio.WavWriter(wav_path)
    try:
        if getattr(engine, "granularity", "chunk") == "sentence":
            times, failures, _ = await _synthesize_sentences(
                engine, chapter, options, semaphore, writer, progress, cancelled)
        else:
            times, failures, _ = await _synthesize_chunks(
                engine, chapter, options, semaphore, writer, progress, cancelled)
        duration = writer.duration_ms
    finally:
        writer.close()

    sentences = []
    for sentence in sentence_list(chapter):
        start_ms, end_ms = times.get(sentence["index"], (0.0, 0.0))
        sentences.append({
            "sentenceIndex": sentence["index"],
            "text": sentence["text"],
            "offsetMs": max(0.0, start_ms),
            "endOffsetMs": max(start_ms + 50, min(end_ms, duration)),
        })
    sentences.sort(key=lambda s: s["sentenceIndex"])

    return {"wav": wav_path, "sentences": sentences, "audioMs": duration, "failures": failures}


# --------------------------------------------------------------------------
# whole job
# --------------------------------------------------------------------------

def _write_mp3_tags(path: Path, *, title: str, album: str, artist: str, narrator: str,
                    track: int, cover: bytes | None, cover_mime: str) -> None:
    from mutagen.id3 import APIC, ID3, TALB, TCON, TIT2, TPE1, TPE2, TRCK

    tags = ID3()
    tags.add(TIT2(encoding=3, text=title))
    tags.add(TALB(encoding=3, text=album))
    tags.add(TPE1(encoding=3, text=artist))
    tags.add(TPE2(encoding=3, text=narrator))
    tags.add(TCON(encoding=3, text="Audiobook"))
    tags.add(TRCK(encoding=3, text=str(track)))
    if cover:
        tags.add(APIC(encoding=3, mime=cover_mime, type=3, desc="Cover", data=cover))
    tags.save(str(path))


async def run_job(job_dir: Path, book_dir: Path, options: dict, progress, cancelled) -> dict:
    """Convert the selected chapters of a stored book."""
    book = load_book(book_dir)
    epub_path = next(iter(sorted(book_dir.glob("*.epub"))), None)
    cover_path = next(iter(sorted(book_dir.glob("cover.*"))), None)
    cover_bytes = cover_path.read_bytes() if cover_path else None
    cover_is_png = bool(cover_path and cover_path.suffix.lower() == ".png")
    cover_mime = "image/png" if cover_is_png else "image/jpeg"

    selected = {int(i) for i in options["chapters"]}
    chapters = [c for c in book["chapters"] if c["index"] in selected]
    if not chapters:
        raise ValueError("no chapters selected")

    mode = options.get("mode", "m4b")
    if mode not in ("m4b", "mp3"):
        raise ValueError(f"unknown output mode {mode!r}")

    engine = engines.get_engine(options.get("engine"))
    ok, detail = engine.available()
    if not ok:
        raise ValueError(f"{engine.label} is not ready: {detail}")

    title = book["title"]
    author = book["author"]
    narrator = options.get("narratorLabel") or "LexiVoice Studio"
    year = str(options.get("year") or "2026")
    genre = options.get("genre") or "Audiobook"

    folder_name = slugify(title)
    out_dir = job_dir / "out" / folder_name
    work_dir = job_dir / "work"
    out_dir.mkdir(parents=True, exist_ok=True)
    work_dir.mkdir(parents=True, exist_ok=True)

    semaphore = asyncio.Semaphore(max(1, int(options.get("concurrency", 3))))
    total_chars = sum(c["chars"] for c in chapters) or 1
    done_chars = 0
    chapter_audio: list[dict] = []
    failures: list[str] = []

    # Paragraphs and sentences are read chapter by chapter while the job runs,
    # so uploading a 200-chapter book stays instant on a slow host.
    if epub_path is None:
        raise ValueError("the book file is missing")
    epub_zip = zipfile.ZipFile(epub_path)
    names = zip_names(epub_zip)

    try:
      for position, chapter in enumerate(chapters):
        if cancelled():
            raise Cancelled()
        chapter = dict(chapter)
        chapter["blocks"] = await asyncio.to_thread(
            chapter_blocks_from_zip, epub_zip, names, chapter["href"])
        if not chapter["blocks"]:
            failures.append(f"{chapter['title']}: no readable text, skipped")
            done_chars += chapter["chars"]
            continue
        progress(
            stage="speech",
            chapterIndex=chapter["index"],
            chapterTitle=chapter["title"],
            chapterPosition=position + 1,
            chapterCount=len(chapters),
            fraction=done_chars / total_chars,
            message=f"Chapter {position + 1}/{len(chapters)}: {chapter['title']}",
        )

        def chapter_progress(_chapter=chapter, _position=position, **kw):
            progress(
                stage="speech",
                chapterIndex=_chapter["index"],
                chapterTitle=_chapter["title"],
                chapterPosition=_position + 1,
                chapterCount=len(chapters),
                fraction=(done_chars + kw.get("fraction", 0) * _chapter["chars"]) / total_chars,
                message=kw.get("message", ""),
            )

        result = await synthesize_chapter(
            engine, chapter, options, semaphore,
            work_dir / f"ch{chapter['index']:04d}.wav",
            chapter_progress, cancelled,
        )
        done_chars += chapter["chars"]
        failures.extend(result["failures"])
        chapter_audio.append({"chapter": chapter, **result})
    finally:
        epub_zip.close()

    if not chapter_audio:
        raise ValueError(
            "none of the selected chapters had readable text — try another chapter "
            "or check that the EPUB is not DRM-protected"
        )

    # ---------------------------------------------------------------- assemble
    progress(stage="assemble", fraction=0.97, message="Assembling the audiobook")

    sync_chapters = []
    outputs: list[dict] = []

    if mode == "m4b":
        m4b_name = f"{folder_name}.m4b"
        m4b_path = out_dir / m4b_name
        def encoding_progress(fraction: float, position: int, count: int) -> None:
            progress(
                stage="assemble",
                fraction=0.9 + 0.08 * fraction,
                message=f"Encoding audio — chapter {position + 1} of {count} ({int(fraction * 100)}%)",
            )

        # Encoding is the heavy step: it runs in a worker thread so the server
        # keeps answering its health check (Render restarts an instance that
        # misses it, which used to kill builds mid-book).
        encoded = await asyncio.to_thread(
            audio.encode_m4b,
            [(item["wav"], item["chapter"]["title"]) for item in chapter_audio],
            m4b_path,
            int(options.get("bitrate", 64000)),
            float(options.get("chapterGapMs", DEFAULT_CHAPTER_GAP_MS)),
            audio.SAMPLE_RATE,
            encoding_progress,
        )

        await asyncio.to_thread(
            mp4tags.write_tags_and_chapters,
            m4b_path,
            tags={
                "title": title,
                "author": author,
                "album": title,
                "narrator": narrator,
                "year": year,
                "genre": genre,
                "album_artist": author,
            },
            chapters=[{"title": c["title"], "startMs": c["startMs"]} for c in encoded["chapters"]],
            cover=cover_bytes,
            cover_is_png=cover_is_png,
        )

        for item, timing in zip(chapter_audio, encoded["chapters"]):
            sync_chapters.append({
                "chapterIndex": item["chapter"]["index"],
                "title": item["chapter"]["title"],
                "fileName": m4b_name,
                "durationMs": timing["durationMs"],
                "sentences": item["sentences"],
            })
        outputs.append({"kind": "m4b", "name": m4b_name, "bytes": m4b_path.stat().st_size,
                        "durationMs": encoded["totalMs"]})
    else:
        for position, item in enumerate(chapter_audio):
            chapter = item["chapter"]
            progress(
                stage="assemble",
                fraction=0.9 + 0.08 * (position / max(1, len(chapter_audio))),
                message=f"Encoding chapter {position + 1} of {len(chapter_audio)}",
            )
            mp3_name = f"{position + 1:03d} - {slugify(chapter['title'], 60)}.mp3"
            mp3_path = out_dir / mp3_name
            duration = await asyncio.to_thread(
                audio.encode_mp3, item["wav"], mp3_path, int(options.get("bitrate", 64000)))
            await asyncio.to_thread(
                _write_mp3_tags,
                mp3_path,
                title=chapter["title"],
                album=title,
                artist=author,
                narrator=narrator,
                track=position + 1,
                cover=cover_bytes,
                cover_mime=cover_mime,
            )
            sync_chapters.append({
                "chapterIndex": chapter["index"],
                "title": chapter["title"],
                "fileName": mp3_name,
                "durationMs": duration,
                "sentences": item["sentences"],
            })
            outputs.append({"kind": "mp3", "name": mp3_name, "bytes": mp3_path.stat().st_size,
                            "durationMs": duration})

    # ------------------------------------------------------------------- maps
    payload = syncmap.build(
        book_title=title,
        author=author,
        narrator=narrator,
        year=year,
        genre=genre,
        source_epub=epub_path.name if epub_path else f"{folder_name}.epub",
        chapters=sync_chapters,
    )
    sync_path = out_dir / "sync_map.json"
    await asyncio.to_thread(syncmap.write, sync_path, payload)
    outputs.append({"kind": "sync_map", "name": "sync_map.json", "bytes": sync_path.stat().st_size})

    if epub_path:
        await asyncio.to_thread(shutil.copy2, epub_path, out_dir / epub_path.name)
        outputs.append({"kind": "epub", "name": epub_path.name, "bytes": epub_path.stat().st_size})
    if cover_path:
        await asyncio.to_thread(shutil.copy2, cover_path, out_dir / f"cover{cover_path.suffix}")
        outputs.append({"kind": "cover", "name": f"cover{cover_path.suffix}",
                        "bytes": cover_path.stat().st_size})

    (out_dir / "README.txt").write_text(
        _bundle_readme(title, author, mode, [o["name"] for o in outputs]), encoding="utf-8")

    # ----------------------------------------------------------------- verify
    progress(stage="verify", fraction=0.99, message="Checking the file the way the app reads it")
    report = await asyncio.to_thread(verify_build, out_dir, payload, mode)

    # ------------------------------------------------------------------- zip
    progress(stage="zip", fraction=0.995, message="Packing the download")
    zip_path = job_dir / f"{folder_name} - LexiVoice.zip"
    def _zip() -> None:
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for file in sorted(out_dir.iterdir()):
                zf.write(file, arcname=f"{folder_name}/{file.name}")

    await asyncio.to_thread(_zip)
    outputs.append({"kind": "zip", "name": zip_path.name, "bytes": zip_path.stat().st_size})

    total_ms = sum(c["durationMs"] for c in sync_chapters)
    progress(stage="done", fraction=1.0, message="Finished")
    return {
        "bookTitle": title,
        "author": author,
        "mode": mode,
        "engine": engine.id,
        "voice": options.get("voice"),
        "folder": folder_name,
        "chapters": len(chapters),
        "totalMs": total_ms,
        "durationLabel": human_duration(total_ms),
        "outputs": outputs,
        "verify": report,
        "failures": failures,
    }


def verify_build(out_dir: Path, payload: dict, mode: str) -> dict:
    """Read the built files back the way LexiVoice does."""
    report: dict = {"ok": True, "checks": [], "problems": [], "warnings": [], "stats": {}}
    report["problems"].extend(syncmap.validate(payload))

    if mode == "m4b":
        m4b_name = payload["chapters"][0]["fileName"] if payload["chapters"] else ""
        m4b_path = out_dir / m4b_name
        chapters = mp4tags.read_chpl(m4b_path) if m4b_path.exists() else []
        tags = mp4tags.read_ilst_tags(m4b_path) if m4b_path.exists() else {}
        report["stats"] = {
            "chapters": len(chapters),
            "title": tags.get("title", ""),
            "author": tags.get("author", ""),
            "coverBytes": tags.get("coverBytes", 0),
            "durationMs": tags.get("durationMs", 0),
        }
        if not chapters:
            report["problems"].append("no chpl chapters were found in the .m4b")
        else:
            report["checks"].append(f"{len(chapters)} chapters read back from chpl")
        if not tags.get("title"):
            report["problems"].append("the .m4b has no title tag")
        else:
            report["checks"].append("title and author tags present")
        if not tags.get("coverBytes"):
            report["warnings"].append("the .m4b has no cover art (the EPUB had none)")
        else:
            size = tags["coverBytes"]
            human = f"{size} B" if size < 1024 else f"{size / 1024:.0f} KB"
            report["checks"].append(f"cover art embedded ({human})")

        # The app builds absolute sentence times by adding chapter durations,
        # so chpl starts must agree with that arithmetic.
        first_by_chapter: dict[int, int] = {}
        for segment in syncmap.flatten(payload):
            first_by_chapter.setdefault(segment["chapterIndex"], segment["startMs"])
        drift = []
        for chapter in chapters:
            if chapter["index"] >= len(payload["chapters"]):
                continue
            mapped = first_by_chapter.get(payload["chapters"][chapter["index"]]["chapterIndex"])
            if mapped is not None and abs(mapped - chapter["startMs"]) > 300:
                drift.append(f"{chapter['title']}: chpl {chapter['startMs']} ms vs map {mapped} ms")
        if drift:
            report["problems"].extend(drift[:5])
        else:
            report["checks"].append("chapter starts match the sync-map timeline")
    else:
        missing = [c["fileName"] for c in payload["chapters"] if not (out_dir / c["fileName"]).exists()]
        if missing:
            report["problems"].append(f"missing chapter files: {', '.join(missing[:3])}")
        else:
            report["checks"].append(f"{len(payload['chapters'])} chapter files present")
        report["stats"] = {"chapters": len(payload["chapters"])}

    total_sentences = sum(len(c["sentences"]) for c in payload["chapters"])
    report["stats"]["sentences"] = total_sentences
    if total_sentences:
        report["checks"].append(f"{total_sentences} sentence timings written")

    report["ok"] = not report["problems"]
    return report


def _bundle_readme(title: str, author: str, mode: str, names: list[str]) -> str:
    listing = "\n".join(f"  - {name}" for name in names)
    what = ("This is a single chaptered .m4b audiobook." if mode == "m4b"
            else "These are per-chapter .mp3 files with an ID3 cover.")
    return f"""{title}
by {author}

Made with LexiVoice Studio.

Contents
{listing}

{what}

How to listen in the LexiVoice Android app
------------------------------------------
1. Copy this whole folder to your phone, e.g. into
   Download/Audiobooks/{slugify(title)}/
2. Open LexiVoice -> Manage Folders and add that folder (or its parent)
   if you have not added it already.
3. Open the Audiobooks tab. The book appears there. Chapters come from the
   .m4b itself, and sync_map.json gives you the Read-Along highlight.

Keep sync_map.json in the same folder as the audio. Without it the book still
plays and chapters still work, but tapping a sentence will not jump the audio.

The .epub is included so the Read-Along view can open the book. Put it in the
same EPUB folder you already watch in LexiVoice; the app links the audiobook to
it by file name.
"""
