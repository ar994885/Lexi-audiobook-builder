"""Cloud engine: Microsoft Edge's neural voices through `edge-tts`.

No API key, no account. It streams audio and `SentenceBoundary` events, and the
boundaries carry the offset and duration of every sentence in 100-ns ticks —
which is what makes an accurate read-along map possible.
"""
from __future__ import annotations

import asyncio
import json
import ssl
import time

import edge_tts
import numpy as np

from .. import config
from ..audio import decode_mp3
from .base import Engine, EngineError, SynthResult

CACHE = config.DATA_DIR / "voices" / "edge_voices.json"
CACHE_TTL = 7 * 24 * 3600

DEFAULT_VOICE = "en-GB-RyanNeural"

PRESETS = [
    {"id": "en-GB-RyanNeural", "label": "Ryan — British, warm male", "locale": "en-GB"},
    {"id": "en-GB-SoniaNeural", "label": "Sonia — British, female", "locale": "en-GB"},
    {"id": "en-US-GuyNeural", "label": "Guy — American, male", "locale": "en-US"},
    {"id": "en-US-AriaNeural", "label": "Aria — American, female", "locale": "en-US"},
    {"id": "en-IN-PrabhatNeural", "label": "Prabhat — Indian English, male", "locale": "en-IN"},
    {"id": "en-IN-NeerjaNeural", "label": "Neerja — Indian English, female", "locale": "en-IN"},
    {"id": "hi-IN-MadhurNeural", "label": "Madhur — Hindi, male", "locale": "hi-IN"},
    {"id": "hi-IN-SwaraNeural", "label": "Swara — Hindi, female", "locale": "hi-IN"},
]


def _configure_ssl() -> None:
    if not config.CA_BUNDLE:
        return
    try:
        edge_tts.communicate._SSL_CTX = ssl.create_default_context(cafile=config.CA_BUNDLE)  # noqa: SLF001
    except Exception:
        pass


class EdgeEngine(Engine):
    id = "edge"
    label = "Cloud — Edge neural voices"
    description = "Free Microsoft neural voices over the network. Best quality, needs internet."
    granularity = "chunk"

    def __init__(self) -> None:
        _configure_ssl()
        self._cache: list[dict] | None = None

    def available(self) -> tuple[bool, str]:
        return True, ""

    async def synthesize(self, text: str, voice: str, rate: float = 0.0, pitch: float = 0.0) -> SynthResult:
        last_error: Exception | None = None
        for attempt in range(4):
            try:
                communicate = edge_tts.Communicate(
                    text,
                    voice or DEFAULT_VOICE,
                    rate=f"{rate:+.0f}%",
                    pitch=f"{pitch:+.0f}Hz",
                    proxy=config.TTS_PROXY,
                )
                audio = bytearray()
                boundaries: list[dict] = []
                async for chunk in communicate.stream():
                    if chunk["type"] == "audio":
                        audio.extend(chunk["data"])
                    elif chunk["type"] in ("SentenceBoundary", "WordBoundary"):
                        boundaries.append({
                            "offsetMs": chunk["offset"] / 10_000.0,
                            "durationMs": chunk["duration"] / 10_000.0,
                            "text": chunk["text"],
                        })
                if len(audio) < 200:
                    raise EngineError("the speech service returned no audio")
                pcm = decode_mp3(bytes(audio))
                if pcm.size == 0:
                    raise EngineError("the audio could not be decoded")
                return SynthResult(pcm=pcm, sample_rate=24000, boundaries=boundaries)
            except Exception as exc:  # noqa: BLE001 - retried, then surfaced
                last_error = exc
                if attempt < 3:
                    await asyncio.sleep(1.5 * (2 ** attempt))
        raise EngineError(f"{type(last_error).__name__}: {last_error}")

    async def voices(self) -> list[dict]:
        if self._cache is not None:
            return self._cache
        if CACHE.exists() and time.time() - CACHE.stat().st_mtime < CACHE_TTL:
            try:
                with open(CACHE, "r", encoding="utf-8") as fh:
                    self._cache = json.load(fh)
                    return self._cache
            except Exception:
                pass
        try:
            raw = await edge_tts.list_voices(proxy=config.TTS_PROXY)
            voices = [
                {
                    "id": v["ShortName"],
                    "label": v.get("FriendlyName", v["ShortName"])
                        .replace("Microsoft ", "").replace(" Online (Natural)", ""),
                    "gender": v.get("Gender", ""),
                    "locale": v.get("Locale", ""),
                    "engine": self.id,
                }
                for v in raw
            ]
            voices.sort(key=lambda v: (v["locale"], v["label"]))
            CACHE.parent.mkdir(parents=True, exist_ok=True)
            with open(CACHE, "w", encoding="utf-8") as fh:
                json.dump(voices, fh)
            self._cache = voices
            return voices
        except Exception:
            # Offline: the page still works with the presets.
            return [{"id": p["id"], "label": p["label"], "locale": p["locale"],
                     "gender": "", "engine": self.id} for p in PRESETS]

    def presets(self) -> list[dict]:
        return PRESETS
