"""`python -m app` starts the server."""
from .main import main

if __name__ == "__main__":
    main()
