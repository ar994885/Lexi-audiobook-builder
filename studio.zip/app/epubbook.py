"""EPUB parsing that matches the way the LexiVoice Android app sees a book.

Chapter indices are spine positions, and sentence indices restart at 0 in every
chapter, because that is exactly what ``EpubParser.kt`` does on the device. The
sync map we generate is only useful if it speaks the same numbering.
"""
from __future__ import annotations

import html as html_module
import json
import re
import warnings
import zipfile
from pathlib import Path

from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
from ebooklib import epub

from .text import collapse_ws, human_duration, split_sentences

BLOCK_TAGS = {
    "p", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "li",
    "pre", "div", "section", "dt", "dd",
}
SKIP_TAGS = {"script", "style", "head", "title"}

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")
_SENT_END_RE = re.compile(r"[.!?…]+[\"'”’)\]]*(?=\s|$)")

EXCLUDE_TITLE_HINTS = ("copyright", "table of contents", "contents", "dedication", "colophon")


def _toc_titles(book) -> dict[str, str]:
    """href (without fragment) -> chapter title, from the book's own navigation."""
    titles: dict[str, str] = {}

    def walk(items) -> None:
        for item in items:
            if isinstance(item, (list, tuple)):
                walk(item)
                continue
            href = getattr(item, "href", None)
            title = getattr(item, "title", None)
            if href and title:
                titles.setdefault(href.split("#")[0], collapse_ws(title))

    try:
        walk(book.toc or [])
    except Exception:
        pass
    return titles


def _cover_bytes(book) -> tuple[bytes | None, str]:
    """Return (image bytes, extension) for the book cover, if it has one."""
    candidates = []
    for item in book.get_items():
        props = getattr(item, "properties", None) or []
        if isinstance(props, str):
            props = [props]
        if "cover-image" in props or getattr(item, "is_cover", False):
            candidates.append(item)
    if not candidates:
        meta_cover = None
        try:
            for value in book.get_metadata("OPF", "cover"):
                if value and value[0]:
                    meta_cover = value[0]
                    break
        except Exception:
            meta_cover = None
        if meta_cover:
            item = book.get_item_with_id(meta_cover)
            if item is not None:
                candidates.append(item)
    if not candidates:
        for item in book.get_items():
            name = (getattr(item, "file_name", None) or getattr(item, "get_name", lambda: "")() or "").lower()
            if getattr(item, "media_type", "").startswith("image") and "cover" in name:
                candidates.append(item)
                break
    for item in candidates:
        try:
            data = item.get_content()
            if data:
                name = (getattr(item, "file_name", None) or "").lower()
                ext = "png" if name.endswith(".png") or data[:4] == b"\x89PNG" else "jpg"
                return data, ext
        except Exception:
            continue
    return None, "jpg"


def _chapter_title(soup, fallback: str) -> str:
    for tag in ("h1", "h2", "h3", "title"):
        node = soup.find(tag)
        if node:
            text = collapse_ws(node.get_text(" "))
            if text and len(text) < 200:
                return text
    return fallback


def _blocks_with_sentences(html: bytes | str, start_sentence_index: int):
    """Split one chapter into paragraphs, then into sentences (app numbering)."""
    soup = BeautifulSoup(html, "lxml")
    for tag in soup.find_all(list(SKIP_TAGS)):
        tag.decompose()
    body = soup.body or soup

    groups: dict[int, dict] = {}
    order: list[int] = []
    for node in body.find_all(string=True):
        if not node.strip():
            continue
        parent = node.parent
        skip = False
        while parent is not None:
            if parent.name in SKIP_TAGS:
                skip = True
                break
            parent = parent.parent
        if skip:
            continue

        # Nearest block ancestor, else the body itself.
        block = node.parent
        while block is not None and block is not body and (block.name or "") not in BLOCK_TAGS:
            block = block.parent
        if block is None:
            block = body
        key = id(block)
        if key not in groups:
            groups[key] = {"node": block, "raw": []}
            order.append(key)
        groups[key]["raw"].append(str(node))

    blocks = []
    sentence_index = start_sentence_index
    for key in order:
        text = collapse_ws("".join(groups[key]["raw"]))
        if not text:
            continue
        sentences = []
        for sentence in split_sentences(text):
            sentences.append({"index": sentence_index, "text": sentence})
            sentence_index += 1
        if sentences:
            blocks.append({"text": text, "sentences": sentences})
    return blocks, sentence_index


def parse_epub(path: Path) -> dict:
    """Parse an EPUB into the chapter/sentence structure the app uses."""
    book = epub.read_epub(str(path), options={"ignore_ncx": False})

    title = "Untitled"
    for value in book.get_metadata("DC", "title"):
        if value and value[0].strip():
            title = collapse_ws(value[0])
            break

    author = ""
    for value in book.get_metadata("DC", "creator"):
        if value and value[0].strip():
            author = collapse_ws(value[0])
            break

    language = ""
    for value in book.get_metadata("DC", "language"):
        if value and value[0].strip():
            language = value[0].strip()
            break

    toc_titles = _toc_titles(book)
    cover, cover_ext = _cover_bytes(book)

    chapters = []
    spine = list(book.spine or [])
    for index, spine_item in enumerate(spine):
        idref = spine_item[0] if isinstance(spine_item, (tuple, list)) else spine_item
        linear = spine_item[1] if isinstance(spine_item, (tuple, list)) and len(spine_item) > 1 else "yes"
        item = book.get_item_with_id(idref)
        if item is None or item.get_type() != 9:  # ebooklib.ITEM_DOCUMENT
            continue
        href = item.get_name() or ""
        try:
            content = item.get_content()
        except Exception:
            continue
        if not content:
            continue

        soup = BeautifulSoup(content, "lxml")
        chapter_title = toc_titles.get(href) or _chapter_title(soup, f"Chapter {index + 1}")
        blocks, _ = _blocks_with_sentences(content, 0)

        sentence_count = sum(len(b["sentences"]) for b in blocks)
        char_count = sum(len(b["text"]) for b in blocks)
        plain = "\n\n".join(b["text"] for b in blocks)

        chapters.append({
            "index": index,
            "href": href,
            "title": chapter_title,
            "linear": str(linear).lower() != "no",
            "sentences": sentence_count,
            "chars": char_count,
            "plain": plain,
            # Rough estimate: ~14 characters of text per second of speech.
            "estimateMs": int(char_count / 14.0 * 1000) if char_count else 0,
            "isFrontMatter": any(h in chapter_title.lower() for h in EXCLUDE_TITLE_HINTS),
        })

    return {
        "cover": cover,
        "title": title,
        "author": author or "Unknown Author",
        "language": language,
        "coverExt": cover_ext,
        "chapters": chapters,
        "totalChars": sum(c["chars"] for c in chapters),
        "totalSentences": sum(c["sentences"] for c in chapters),
        "estimateMs": sum(c["estimateMs"] for c in chapters),
    }


def _quick_text(content: bytes | str) -> str:
    """Strip tags without a parser: fast enough to run over a whole book."""
    raw = content.decode("utf-8", "ignore") if isinstance(content, bytes) else content
    raw = re.sub(r"<(script|style)\b.*?</\1>", " ", raw, flags=re.I | re.S)
    text = _TAG_RE.sub(" ", raw)
    return _WS_RE.sub(" ", html_module.unescape(text)).strip()


def zip_names(zf: zipfile.ZipFile) -> dict:
    """Zip entries, indexed exactly and by suffix.

    ebooklib reports an item's name relative to the OPF's folder (`ch1.xhtml`)
    while the archive stores it under that folder (`epub/ch1.xhtml`), so a
    suffix match is needed as well as an exact one.
    """
    entries = [name for name in zf.namelist() if not name.endswith("/")]
    return {"exact": {name.lower(): name for name in entries}, "all": entries}


def chapter_blocks_from_zip(zf: zipfile.ZipFile, names: dict, href: str) -> list[dict]:
    """Build one chapter's paragraphs and sentences from an open EPUB zip."""
    key = href.lower().lstrip("/")
    entry = names["exact"].get(key)
    if entry is None:
        for name in names["all"]:
            lowered = name.lower()
            if lowered.endswith("/" + key) or lowered.endswith(key):
                entry = name
                break
    if entry is None:
        return []
    try:
        content = zf.read(entry)
    except Exception:
        return []
    blocks, _ = _blocks_with_sentences(content, 0)
    return blocks


def summarize(parsed: dict) -> dict:
    """JSON-safe view of a parsed book (no block bodies) for the browser."""
    return {
        "title": parsed["title"],
        "author": parsed["author"],
        "language": parsed["language"],
        "hasCover": bool(parsed.get("cover")),
        "totalChars": parsed["totalChars"],
        "totalSentences": parsed["totalSentences"],
        "estimateMs": parsed["estimateMs"],
        "estimateLabel": human_duration(parsed["estimateMs"]),
        "chapters": [
            {
                "index": c["index"],
                "title": c["title"],
                "sentences": c["sentences"],
                "chars": c["chars"],
                "estimateMs": c["estimateMs"],
                "estimateLabel": human_duration(c["estimateMs"]),
                "isFrontMatter": c["isFrontMatter"],
                "linear": c["linear"],
            }
            for c in parsed["chapters"]
        ],
    }


def load_book(book_dir: Path) -> dict:
    with open(book_dir / "book.json", "r", encoding="utf-8") as fh:
        return json.load(fh)


def save_book(book_dir: Path, parsed: dict, cover: bytes | None) -> None:
    book_dir.mkdir(parents=True, exist_ok=True)
    payload = {k: v for k, v in parsed.items() if k != "cover"}
    with open(book_dir / "book.json", "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False)
    if cover:
        with open(book_dir / f"cover.{parsed.get('coverExt', 'jpg')}", "wb") as fh:
            fh.write(cover)


def natural_title_from_filename(name: str) -> str:
    stem = re.sub(r"\.epub$", "", name, flags=re.I)
    stem = stem.replace("_", " ").strip()
    return collapse_ws(stem) or "Untitled"
