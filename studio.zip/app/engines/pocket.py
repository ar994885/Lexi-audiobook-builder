"""Local engine: Kyutai Pocket TTS, exported to one self-contained ONNX file.

Unlike a Piper voice, this is a whole model in a single file: the graph, the
tokenizer, the voice encoder and a handful of ready-made voices all live inside
the `.onnx` (`thewh1teagle/pocket-tts-onnx`). So one file gives you several
voices, and any other voice is a cloning prompt:

    models/pocket/pocket-tts-english.onnx        built-in voices
    models/pocket/clones/<model>/<name>.npy      a cloned voice prompt

Voice ids are `<model stem>::<voice>`, e.g. `pocket-tts-english::alba`, or
`pocket-tts-english::clone:my-voice`.

The model has no speaking-rate control, so speed is applied afterwards with the
WSOLA stretch from the project's own `examples/speed.py` — pitch is preserved,
and there is no pitch parameter to fake.
"""
from __future__ import annotations

import asyncio
import json
import threading
from pathlib import Path

import numpy as np

from .. import config
from .base import Engine, EngineError, SynthResult

VOICE_CACHE = config.DATA_DIR / "voices" / "pocket_voices.json"


def model_dir() -> Path:
    return config.MODELS_DIR / "pocket"


def clone_dir(stem: str) -> Path:
    return model_dir() / "clones" / stem


def _models() -> list[Path]:
    if not model_dir().exists():
        return []
    return sorted(p for p in model_dir().glob("*.onnx") if p.is_file())


def _cache() -> dict:
    if VOICE_CACHE.exists():
        try:
            with open(VOICE_CACHE, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return {}
    return {}


def _save_cache(data: dict) -> None:
    VOICE_CACHE.parent.mkdir(parents=True, exist_ok=True)
    with open(VOICE_CACHE, "w", encoding="utf-8") as fh:
        json.dump(data, fh)


def _clones(stem: str) -> list[str]:
    folder = clone_dir(stem)
    if not folder.exists():
        return []
    return sorted(p.stem for p in folder.glob("*.npy"))


def discover(include_builtin: bool = True) -> list[dict]:
    """Every voice this engine can offer, without loading a model when cached."""
    cached = _cache()
    found: list[dict] = []
    for path in _models():
        stem = path.stem
        builtin = cached.get(stem, [])
        size = path.stat().st_size
        if include_builtin:
            if builtin:
                for name in builtin:
                    found.append({
                        "id": f"{stem}::{name}",
                        "label": f"{name.title()} — {stem}",
                        "locale": "",
                        "engine": "pocket",
                        "model": stem,
                        "sizeBytes": size,
                    })
            else:
                found.append({
                    "id": f"{stem}::",
                    "label": f"{stem} (voices load on first use)",
                    "locale": "",
                    "engine": "pocket",
                    "model": stem,
                    "sizeBytes": size,
                    "unloaded": True,
                })
        for name in _clones(stem):
            found.append({
                "id": f"{stem}::clone:{name}",
                "label": f"{name} (cloned) — {stem}",
                "locale": "",
                "engine": "pocket",
                "model": stem,
                "sizeBytes": size,
            })
    return found


class PocketEngine(Engine):
    id = "pocket"
    label = "Local — Pocket TTS (single .onnx)"
    description = "Kyutai Pocket TTS in one file: built-in voices plus cloning. Slower than Piper."
    granularity = "sentence"

    def __init__(self) -> None:
        self._models: dict[str, object] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ setup
    def available(self) -> tuple[bool, str]:
        try:
            import pocket_tts_onnx  # noqa: F401
        except Exception:
            return False, "pocket-tts-onnx is not installed"
        if not _models():
            return False, "No Pocket TTS .onnx in models/pocket/"
        return True, ""

    async def voices(self) -> list[dict]:
        cached = _cache()
        missing = [p for p in _models() if p.stem not in cached]
        if missing:
            loop = asyncio.get_running_loop()
            for path in missing:
                try:
                    names = await loop.run_in_executor(None, self._builtin_voices, path)
                    cached[path.stem] = names
                except Exception:
                    cached[path.stem] = []
            _save_cache(cached)
        return [v for v in discover() if not v.get("unloaded")]

    def presets(self) -> list[dict]:
        return []

    # ------------------------------------------------------------------ model
    def _load(self, stem: str):
        with self._lock:
            model = self._models.get(stem)
            if model is not None:
                return model
            path = model_dir() / f"{stem}.onnx"
            if not path.exists():
                raise EngineError(f"model '{stem}' is not in {model_dir()}")
            try:
                from pocket_tts_onnx import PocketTTS
            except Exception as exc:  # noqa: BLE001
                raise EngineError(f"pocket-tts-onnx is not installed: {exc}") from exc
            try:
                model = PocketTTS(str(path))
            except Exception as exc:  # noqa: BLE001
                raise EngineError(f"could not load '{stem}': {exc}") from exc
            self._models[stem] = model
            return model

    def _builtin_voices(self, path: Path) -> list[str]:
        model = self._load(path.stem)
        return list(model.voices())

    # -------------------------------------------------------------- synthesis
    def _synthesize_sync(self, text: str, voice_id: str, rate: float) -> SynthResult:
        stem, _, voice = voice_id.partition("::")
        model = self._load(stem)
        if not voice:
            names = model.voices()
            if not names:
                raise EngineError("this model carries no built-in voice; clone one first")
            voice = names[0]

        if voice.startswith("clone:"):
            name = voice.split(":", 1)[1]
            path = clone_dir(stem) / f"{name}.npy"
            if not path.exists():
                raise EngineError(f"cloned voice '{name}' is missing")
            conditioning = np.load(path)
        else:
            conditioning = voice

        samples, sample_rate = model.create(text, voice=conditioning)
        samples = np.asarray(samples, dtype=np.float32).reshape(-1)

        if abs(rate) >= 1.0:
            samples = stretch(samples, 1.0 + rate / 100.0, sample_rate)

        pcm = np.clip(samples * 32767.0, -32768, 32767).astype(np.int16)
        return SynthResult(pcm=pcm, sample_rate=sample_rate, boundaries=[])

    async def synthesize(self, text: str, voice: str, rate: float = 0.0, pitch: float = 0.0) -> SynthResult:
        if not voice:
            options = discover()
            if not options:
                raise EngineError("no Pocket TTS model is installed")
            voice = options[0]["id"]
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._synthesize_sync, text, voice, rate)

    # ---------------------------------------------------------------- cloning
    def clone_from_wav(self, stem: str, name: str, wav_path: Path) -> dict:
        model = self._load(stem)
        conditioning = model.clone_voice(str(wav_path))
        target = clone_dir(stem)
        target.mkdir(parents=True, exist_ok=True)
        safe = "".join(ch for ch in name if ch.isalnum() or ch in "-_") or "voice"
        path = target / f"{safe}.npy"
        np.save(path, conditioning)
        return {"id": f"{stem}::clone:{safe}", "label": f"{safe} (cloned) — {stem}",
                "engine": "pocket", "model": stem}


def stretch(samples: np.ndarray, factor: float, sample_rate: int) -> np.ndarray:
    """Play `samples` `factor` times faster, pitch preserved (WSOLA).

    The same overlap-add the project's `examples/speed.py` uses: 40 ms windows,
    each nudged by up to ±10 ms to the offset that continues the previous one.
    """
    if abs(factor - 1.0) < 1e-3 or samples.size < sample_rate // 4:
        return samples
    window = int(0.040 * sample_rate)
    hop = window // 2
    search = int(0.010 * sample_rate)
    taper = np.hanning(window).astype(np.float32)

    length = int(len(samples) / factor)
    out = np.zeros(length + window, dtype=np.float32)
    norm = np.zeros(length + window, dtype=np.float32)

    position = 0.0
    for start in range(0, length, hop):
        centre = int(position)
        lo = max(0, centre - search)
        hi = min(len(samples) - window, centre + search)
        if hi <= lo:
            break
        target = out[start:start + hop]
        best, best_score = lo, -np.inf
        for offset in range(lo, hi + 1, max(1, search // 16)):
            score = float(np.dot(samples[offset:offset + hop], target))
            if score > best_score:
                best, best_score = offset, score
        out[start:start + window] += samples[best:best + window] * taper
        norm[start:start + window] += taper
        position += hop * factor

    norm[norm < 1e-3] = 1.0
    return (out / norm)[:length]


def register_model(onnx_bytes: bytes, stem: str) -> dict:
    """Store an uploaded Pocket TTS .onnx and warm its voice list."""
    name = "".join(ch for ch in stem if ch.isalnum() or ch in "-_.") or "pocket-tts"
    model_dir().mkdir(parents=True, exist_ok=True)
    path = model_dir() / f"{name}.onnx"
    path.write_bytes(onnx_bytes)

    try:
        from pocket_tts_onnx import PocketTTS
        model = PocketTTS(str(path))
        names = list(model.voices())
    except Exception as exc:  # noqa: BLE001
        raise EngineError(f"that file did not load as a Pocket TTS model: {exc}") from exc

    cache = _cache()
    cache[name] = names
    _save_cache(cache)
    return {"model": name, "voices": names}
