"""Speech engine interface.

An engine turns text into mono int16 PCM plus, when it can, the timing of each
sentence it spoke. Two granularities exist:

``chunk``
    The engine likes long text and reports sentence boundaries itself
    (edge-tts). The pipeline sends runs of sentences and maps the boundaries
    back onto the app's sentence indices.

``sentence``
    The engine is fast and local, so the pipeline sends one sentence at a time
    and the timing is exact by construction (Piper / local ONNX voices).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


class EngineError(RuntimeError):
    pass


@dataclass
class SynthResult:
    pcm: np.ndarray                 # int16, mono
    sample_rate: int
    boundaries: list[dict] = field(default_factory=list)


class Engine:
    id: str = "base"
    label: str = "Base"
    description: str = ""
    granularity: str = "chunk"

    def available(self) -> tuple[bool, str]:
        return True, ""

    async def synthesize(self, text: str, voice: str, rate: float = 0.0, pitch: float = 0.0) -> SynthResult:
        raise NotImplementedError

    async def voices(self) -> list[dict]:
        return []

    def presets(self) -> list[dict]:
        return []
